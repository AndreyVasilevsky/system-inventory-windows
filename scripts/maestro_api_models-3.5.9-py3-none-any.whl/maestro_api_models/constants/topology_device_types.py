# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials, and your use of them is governed
# by the express license under which they were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit this software or the related documents
# without Intel's prior written permission.
#
# This software and the related documents are provided as is, with no express or implied warranties,
# other than those that are expressly stated in the License.

# Standard Library Imports

# Third party imports...
from enum import Enum


class TopologyDeviceTypes(Enum):
    """
    Topology Device Types Enum.

    Naming schema of any future ENUM types added to this class need to be in the format of:
    <DEVICE_INSTANCE_SQL_ALCHEMY_CLASS_NAME_CONVERTED_TO_SNAKE_CASE> = "User Friendly Name for Inventory Item"
    """

    SYSTEM_INSTANCE = "System"
    SWITCH_INSTANCE = "Switch"
    KVM_INSTANCE = "KVM"
    ETHERNET_CONTROLLER_INSTANCE = "Ethernet Controller"
