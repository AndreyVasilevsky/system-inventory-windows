# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Standard library imports
import sys

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator

# Local library imports
from maestro_api_models.common.model_utils import get_model_fields
from maestro_api_models.models.data.reservation.model import ReservationModelBasic

from . import sample


class AvailabilityStatusTypes:
    """
    Defined and accepted values for availability status of a system.

    - 'available' (System is available for use)
    - 'unavailable' (System is not available for use)
    - 'decommissioned' (System has been decommissioned/archived permanently)

    - 'early-access' (System is part of the Maestro Early Access program, and is not yet tracked for availability)
    """

    AVAILABLE = "available"
    UNAVAILABLE = "unavailable"
    DECOMMISSIONED = "decommissioned"
    EARLY_ACCESS = "early-access"


class ReservationStatusTypes:
    """
    Defined and accepted values for reservation status of a system.

    - 'available' (System is unreserved and has zero pending future reservations in the queue)
    - 'reserved' (System is currently in the middle of an active reservation)
    - 'pending' (System not currently actively reserved, but has at least one reservation in the queue)
    """

    AVAILABLE = "available"
    RESERVED = "reserved"
    PENDING = "pending"


class SystemStatusModel(BaseModel):
    # AvailabilityStatusTypes
    availability: str | None = None

    # ReservationStatusTypes
    reservation_current: str | None = None
    reservation: ReservationModelBasic | None = None
    model_config = ConfigDict(
        json_schema_extra={"example": sample.SYSTEM_STATUS_SAMPLE}
    )

    @field_validator("availability")
    @classmethod
    def valid_status_availability(cls, v):
        if v is not None:
            valid_status_list = get_model_fields(
                sys.modules[__name__], "AvailabilityStatusTypes"
            )
            if v not in valid_status_list:
                raise ValueError(f"invalid availability status: {v}")
        return v

    @field_validator("reservation_current")
    @classmethod
    def valid_status_reservation_current(cls, v):
        if v is not None:
            valid_status_list = get_model_fields(
                sys.modules[__name__], "ReservationStatusTypes"
            )
            if v not in valid_status_list:
                raise ValueError(f"invalid reservation status: {v}")
        return v
