# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict, model_validator, Field
from typing import Optional


# Local package imports

from . import sample

from maestro_api_models.common.data_validators.network_validators import valid_domain
from maestro_api_models.common.model_utils import extract_fqdn, ensure_https


class CcsgBase(BaseModel):
    ccsg_instance_id: Optional[int] = Field(None, alias="id")
    ccsg_url: Optional[str] = Field(None, alias="url")
    display_name: str | None = None

    model_config = ConfigDict(
        json_schema_extra={"example": sample.CCSG_BASE_SAMPLE},
        from_attributes=True,
        populate_by_name=True,
    )

    @model_validator(mode="before")
    def check_ccsg_data(cls, v):
        if isinstance(v, dict):
            if v.get("ccsg_url") is not None:
                v["ccsg_url"] = cls.__check_ccsg_url(v)
            return v
        else:
            return None

    @staticmethod
    def __check_ccsg_url(v):
        """Valiate the CCSG URL if its not empty."""
        if v["ccsg_url"] is not None:
            try:
                ccsg_url = extract_fqdn(v["ccsg_url"])
                if not valid_domain(ccsg_url):
                    raise ValueError(
                        "Invalid CCSG Address, please be sure to use the proper FQDN for the CCSG, "
                        + "we do not support IP addresses"
                    )
                return ensure_https(ccsg_url)
            except ValueError as err:
                raise err
