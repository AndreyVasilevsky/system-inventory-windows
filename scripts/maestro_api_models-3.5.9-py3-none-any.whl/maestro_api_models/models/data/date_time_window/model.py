# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Standard library imports
from datetime import datetime

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator

from maestro_api_models.common.validators import valid_datetime_utc
from maestro_api_models.models.data.date_time_window.sample import (
    DATE_TIME_WINDOW_SAMPLE,
)


class DateTimeWindow(BaseModel):
    """Simple class containing set of start and end datetimes, used to define a window of time for backend logic."""

    start: datetime | None = None
    end: datetime | None = None

    @field_validator("start", "end")
    @classmethod
    def datetime_utc_format(cls, v):
        if v is not None:
            valid_datetime_utc(v)
        return v

    model_config = ConfigDict(
        json_schema_extra={"example": DATE_TIME_WINDOW_SAMPLE}, validate_assignment=True
    )
