# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator


# Local package imports
from maestro_api_models.common.data_validators.network_validators import (
    valid_domain,
)
from . import sample


class CcsgAddressModel(BaseModel):
    ccsg_fqdn: str

    model_config = ConfigDict(
        json_schema_extra={"example": sample.CCSG_ADDRESS_SAMPLE},
        from_attributes=True,
    )

    @field_validator("ccsg_fqdn")
    @classmethod
    def ccsg_fqdn_valid(cls, v):
        if v is not None:
            if valid_domain(v):
                return v
            else:
                raise ValueError("CCSG FQDN is either invalid or empty, please correct")
