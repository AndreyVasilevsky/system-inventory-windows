# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict, Field, field_validator

# Local package imports
from maestro_api_models.common import validators
from maestro_api_models.common.data_validators.network_validators import (
    valid_ip_address,
)
from maestro_api_models.common.data_validators.credential_validators import (
    valid_pass,
    valid_user_linux,
)
from . import sample


class KVMModel(BaseModel):
    kvm_instance_id: int | None = Field(None, alias="id")
    kvm_id: int | None = None
    firmware: str | None = None
    inventory_id: str | None = None
    manufacturer: str | None = None
    serial_number: str | None = None
    mgt_ip_address: str | None = None
    mgt_username: str | None = None
    mgt_password: str | None = None
    name_model: str | None = None
    port_count: int | None = None
    url: str | None = None
    version: str | None = None
    lab_row_rack_id: int | None = None

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={"example": sample.KVM_SAMPLE},
    )

    @field_validator("kvm_id")
    @classmethod
    def kvm_id_range(cls, v):
        if v is not None:
            validators.valid_db_id_signed(v)
        return v

    @field_validator("firmware", "manufacturer", "name_model", "version")
    @classmethod
    def char_limit_50(cls, v):
        # VARCHAR(50) in Inventory DB
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=50)
        return v

    @field_validator("inventory_id")
    @classmethod
    def inventory_id_char_limit(cls, v):
        # VARCHAR(64) in Inventory DB
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=64)
        return v

    @field_validator("mgt_ip_address")
    @classmethod
    def ip_address_format(cls, v):
        if v is not None:
            if not valid_ip_address(v):
                raise ValueError(f"Invalid IPv4 address: {v}")
        return v

    @field_validator("mgt_username")
    @classmethod
    def valid_mgt_user(cls, v):
        """Verify that switch management user is a valid.

        Raises:
            ValueError
        """
        if v is not None:
            valid_user_linux(v, False)
            return v

    @field_validator("mgt_password")
    @classmethod
    def valid_mgt_password(cls, v):
        """Verify that switch management password is a valid.

        Raises:
            ValueError
        """
        if v is not None:
            valid_pass(v, False)
            return v

    @field_validator("port_count")
    @classmethod
    def positive_value(cls, v):
        if v is not None:
            validators.positive_number(v)
        return v

    @field_validator("url")
    @classmethod
    def url_char_limit(cls, v):
        # VARCHAR(2048) in Inventory DB
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=2048)
        return v
