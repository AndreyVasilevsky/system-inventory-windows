# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

KVM_SAMPLE = {
    "kvm_id": 1,
    "firmware": "GLaDOS.v1",
    "inventory_id": "1092007",
    "manufacturer": "AS Labs",
    "serial_number": "1234567890",
    "mgt_ip_address": "104.112.164.249",
    "mgt_username": "admin",
    "mgt_password": "admin",
    "name_model": "APC_McLain",
    "port_count": 6,
    "url": "http://connect.to.this.kvm/direct/monitor",
    "version": "1",
}

KVM_SAMPLE_NO_INSTANCE_ID = {
    "kvm_instance_id": 10,
    "kvm_id": 1,
    "firmware": "GLaDOS.v1",
    "inventory_id": "1092007",
    "manufacturer": "AS Labs",
    "serial_number": "1234567890",
    "mgt_ip_address": "104.112.164.249",
    "mgt_username": "admin",
    "mgt_password": "admin",
    "name_model": "APC_McLain",
    "port_count": 6,
    "url": "http://connect.to.this.kvm/direct/monitor",
    "version": "1",
}
