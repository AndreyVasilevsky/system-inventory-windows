# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator

# Local package imports
from maestro_api_models.common import validators
from . import sample


class MotherboardModel(BaseModel):
    motherboard_id: int | None = None
    cpu_numa_count: int | None = None
    cpu_sockets_count: int | None = None
    max_pcie_gen: float | None = None
    product: str | None = None
    serial_number: str | None = None
    vendor: str | None = None
    version: str | None = None

    model_config = ConfigDict(json_schema_extra={"example": sample.MOTHERBOARD_SAMPLE})

    @field_validator("motherboard_id")
    @classmethod
    def motherboard_id_range(cls, v):
        if v is not None:
            validators.valid_db_id_signed(v)
        return v

    @field_validator("product", "serial_number", "vendor", "version")
    @classmethod
    def char_limit_50(cls, v):
        # VARCHAR(50) in Inventory DB
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=50)
        return v

    @field_validator("cpu_numa_count", "cpu_sockets_count")
    @classmethod
    def positive_value(cls, v):
        if v is not None:
            validators.positive_number(v)
        return v

    def __hash__(self) -> int:
        return hash((self.motherboard_id, self.product))
