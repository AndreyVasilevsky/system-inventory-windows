# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator

# Local package imports
from maestro_api_models.common import validators
from . import sample


class PCIVendorModel(BaseModel):
    vendor_id: str | None = None
    name: str | None = None

    model_config = ConfigDict(
        json_schema_extra={"example": sample.ETHERNET_CONTROLLER_VENDOR_SAMPLE}
    )

    @field_validator("vendor_id")
    @classmethod
    def is_hex_value(cls, v):
        if v is not None:
            try:
                validators.valid_char_count(char_str=v, max_len=6)
                int(v, 16)
                if v[:2] != "0x":
                    raise ValueError
            except ValueError:
                raise ValueError(
                    'must be a valid hexadecimal string of 6 characters or less, beginning with "0x"'
                    '(example: "0x1234")'
                )
        return v

    @field_validator("name")
    @classmethod
    def is_char_count_128(cls, v):
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=128)
        return v

    def __eq__(self, other):
        if isinstance(other, PCIVendorModel):
            return self.vendor_id == other.vendor_id
        return False

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(self.vendor_id)


class PCIDeviceModel(BaseModel):
    device_id: str | None = None
    name: str | None = None
    vendor: PCIVendorModel | None = None

    model_config = ConfigDict(
        json_schema_extra={"example": sample.ETHERNET_CONTROLLER_DEVICE_SAMPLE}
    )

    @field_validator("device_id")
    @classmethod
    def is_hex_value(cls, v):
        if v is not None:
            try:
                validators.valid_char_count(char_str=v, max_len=6)
                int(v, 16)
                if v[:2] != "0x":
                    raise ValueError
            except ValueError:
                raise ValueError(
                    'must be a valid hexadecimal string of 6 characters or less, beginning with "0x"'
                    '(example: "0x1234")'
                )
        return v

    @field_validator("name")
    @classmethod
    def is_char_count_128(cls, v):
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=128)
        return v

    def __eq__(self, other):
        if isinstance(other, PCIDeviceModel):
            return self.device_id == other.device_id and self.vendor == other.vendor
        return False

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self) -> int:
        return hash((self.device_id, self.vendor))


class PCISubDeviceModel(BaseModel):
    sub_device_id: str | None = None
    name: str | None = None
    device: PCIDeviceModel | None = None
    subvendor: PCIVendorModel | None = None

    model_config = ConfigDict(
        json_schema_extra={"example": sample.ETHERNET_CONTROLLER_SUB_DEVICE_SAMPLE}
    )

    @field_validator("sub_device_id")
    @classmethod
    def is_hex_value(cls, v):
        if v is not None:
            try:
                validators.valid_char_count(char_str=v, max_len=6)
                int(v, 16)
                if v[:2] != "0x":
                    raise ValueError
            except ValueError:
                raise ValueError(
                    'must be a valid hexadecimal string of 6 characters or less, beginning with "0x"'
                    '(example: "0x1234")'
                )
        return v

    @field_validator("name")
    @classmethod
    def is_char_count_128(cls, v):
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=128)
        return v

    def __eq__(self, other):
        if isinstance(other, PCISubDeviceModel):
            return (
                self.sub_device_id == other.sub_device_id
                and self.device == other.device
                and self.subvendor == other.subvendor
            )
        return False

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self) -> int:
        return hash((self.sub_device_id, self.device, self.subvendor))
