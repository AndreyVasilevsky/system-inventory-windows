# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict, model_validator
from paramiko import RSAKey
from typing import Union
from io import StringIO

# Local package imports

from maestro_api_models.common.data_validators.certificate_validators import (
    CertificateValidators,
)

from . import sample


class RsaKey(BaseModel):
    rsa_key: Union[str, RSAKey]

    model_config = ConfigDict(
        json_schema_extra={"example": sample.RSA_SAMPLE},
        arbitrary_types_allowed=True,
        from_attributes=True,
    )

    @model_validator(mode="before")
    def check_rsa_key(cls, v):
        if v is not None:
            if isinstance(v, dict):
                if isinstance(v["rsa_key"], str):
                    if CertificateValidators.string_is_private_key(v["rsa_key"]):
                        dummykeyfile = StringIO(v["rsa_key"])
                        v["rsa_key"] = RSAKey.from_private_key(dummykeyfile)
                        return v
                    else:
                        raise ValueError("Data Supplied is not a valid RSA Key.")

                if isinstance(v["rsa_key"], RSAKey):
                    return v
                else:
                    raise ValueError("Data Supplied is not a valid RSA Key.")
            else:
                raise ValueError("RSA Key Data cannot be blank.")

    def json(self, **kwargs):
        # Convert Paramiko RSA key to string representation if it exists
        if type(self.rsa_key) is RSAKey:
            rsa_key_str = self.rsa_key.get_base64()
        else:
            rsa_key_str = self.rsa_key

        # Call the parent class's json() method and modify the output
        json_dict = super().json(**kwargs)
        json_dict["rsa_key"] = rsa_key_str
        return json_dict
