# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator

# Local package imports
from maestro_api_models.common import validators
from maestro_api_models.models.data.lab.model import LabModel
from . import sample


class LabRowRackModel(BaseModel):
    id: int | None = None
    lab_row: str | None = None
    lab_rack: str | None = None
    lab_id: int | None = None
    lab: LabModel | None = None

    model_config = ConfigDict(
        from_attributes=True, json_schema_extra={"example": sample.LAB_ROW_RACK_SAMPLE}
    )

    @field_validator("id", "lab_id")
    @classmethod
    def lab_id_range(cls, v):
        if v is not None:
            validators.valid_db_id_signed(v)
        return v

    @field_validator("lab_row", "lab_rack")
    @classmethod
    def char_limit_64(cls, v):
        # VARCHAR(64) in Inventory DB
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=64)
        return v
