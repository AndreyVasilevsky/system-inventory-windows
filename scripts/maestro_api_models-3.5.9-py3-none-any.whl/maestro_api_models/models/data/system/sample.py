# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Local library imports
from maestro_api_models.constants.power_commands import PowerCommands
from maestro_api_models.models.data.bios.sample import BIOS_SAMPLE
from maestro_api_models.models.data.bmc.sample import BMC_SAMPLE
from maestro_api_models.models.data.cpu.sample import CPU_SAMPLE
from maestro_api_models.models.data.ethernet_controller.sample import (
    ETHERNET_CONTROLLER_SAMPLE,
)
from maestro_api_models.models.data.hard_drive.sample import HARD_DRIVE_SAMPLE
from maestro_api_models.models.data.kvm.sample import KVM_SAMPLE
from maestro_api_models.models.data.memory_bank.sample import MEMORY_BANK_SAMPLE
from maestro_api_models.models.data.motherboard.sample import MOTHERBOARD_SAMPLE
from maestro_api_models.models.data.reservation.sample import RES_MODEL_SAMPLE
from maestro_api_models.models.data.system_status.sample import SYSTEM_STATUS_SAMPLE
from maestro_api_models.models.data.system_extended_field.sample import (
    SYSTEM_EXTENDED_FIELD_SAMPLE,
)
from maestro_api_models.models.data.inventory.pdu.sample import SYSTEM_OUTLET_MAP


SYSTEM_BASIC_SAMPLE = {
    "system_id": 10,
    "description": "JF3418-7A20-30351-DarkStar-N8-P1",
    "inventory_id": "1234abcd",
    "manufacturer": "Mao-Kwikowski Mercantile (Sample)",
    "mgt_ip_address": "86.7.53.09",
    "mgt_mac_address": "0F:F0:0F:F0:0F:F0",
    "name_model": "CA_2216862",
    "pools": ["tiger team pool", "lion team pool"],
    "serial_number": "12345",
    "sku": "BA-834024112",
    "uuid": "12345678-1234-1234-1234-123456789012",
    "version": "0.9",
    "bmc": BMC_SAMPLE,
    "motherboard": MOTHERBOARD_SAMPLE,
    "status": SYSTEM_STATUS_SAMPLE,
    "lab_row_rack_id": 1,
}

SYSTEM_SAMPLE = {}
SYSTEM_SAMPLE.update(SYSTEM_BASIC_SAMPLE)
SYSTEM_SAMPLE.update(
    {
        "bios": BIOS_SAMPLE,
        "cpus": [CPU_SAMPLE],
        "ethernet_controllers": [ETHERNET_CONTROLLER_SAMPLE],
        "extended_fields": [SYSTEM_EXTENDED_FIELD_SAMPLE],
        "hard_drives": [HARD_DRIVE_SAMPLE],
        "kvm": KVM_SAMPLE,
        "kvm_dongle_serial_number": "7H3C4K3154L13",
        "kvm_node_group": "BMRF",
        "kvm_node_interface_label": "BMRF-17-APERTURE-01-P31",
        "kvm_node_label": "BMRF-17-APERTURE",
        "memory_banks": [MEMORY_BANK_SAMPLE],
        "pdus": SYSTEM_OUTLET_MAP,
        "power_options": [
            PowerCommands.POWER_ON,
            PowerCommands.POWER_OFF,
        ],
        "current_max_supported_pcie_gen": 4.0,
    }
)

SYSTEM_BASIC_RES_SAMPLE = {}
SYSTEM_BASIC_RES_SAMPLE.update(SYSTEM_BASIC_SAMPLE)
SYSTEM_BASIC_RES_SAMPLE.update(
    {
        "reservations": [RES_MODEL_SAMPLE],
    }
)

SYSTEM_MODEL_BASE_SAMPLE = {
    "created_date": "2022-01-01T00:00:00",
    "description": "This is a SUT",
    "inventory_id": "BC123456789",
    "kvm_node_interface_label": "BMRF-17-APERTURE-01-P31",
    "kvm_node_label": "BMRF-17-APERTURE",
    "lab_row_rack_id": 1,
    "lab_rack_slot": 1,
    "last_inventory_date": "2022-01-01T00:00:00",
    "mgt_mac_address": "0F:0F:0F:0F:0F:0F",
    "serial_number": "12345",
    "system_id": 10,
    "sku": "BA-834024112",
    "uuid": "12345678-1234-1234-1234-123456789012",
    "version": "0.9",
}

SYSTEM_INSTANCE_MODEL_SAMPLE = {
    "bios_date": "2020-11-01T00:00:00",
    "bios_vendor": "Intel Corporation",
    "bios_version": "SE5C620.86B.01.01.0001.101920201000",
    "bmc_firmware_revision": "1.0.0",
    "bmc_guid": "12345678-1234-1234-1234-123456789012",
    "bmc_ip_address": "10.10.10.10",
    "bmc_mac_address": "F0:F0:F0:F0:F0:F0",
    "bmc_password": "password",
    "bmc_username": "admin",
    "bmc_vlan": 1,
    "motherboard_serial_number": "12345678",
    "bmc_manufacturer_id": 1,
    "chassis_id": 1,
    "kvm_instance_id": 1,
    "kvm_node_group_id": 1,
    "manufacturer_id": 1,
    "status_availability_id": 1,
}
SYSTEM_INSTANCE_MODEL_SAMPLE = SYSTEM_INSTANCE_MODEL_SAMPLE.update(
    SYSTEM_MODEL_BASE_SAMPLE
)
