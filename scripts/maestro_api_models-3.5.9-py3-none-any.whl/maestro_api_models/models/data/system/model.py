# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Standard library imports
from datetime import datetime
from typing import List

# Third party library imports
from pydantic import BaseModel, ConfigDict, SecretStr, computed_field, field_validator

# Local package imports
from maestro_api_models.common import validators
from maestro_api_models.constants.power_commands import PowerCommands
from maestro_api_models.models.data.bios.model import BIOSModel
from maestro_api_models.models.data.bmc.model import BMCModel
from maestro_api_models.models.data.ccsg_base.model import CcsgBase
from maestro_api_models.models.data.cpu.model import CPUModel
from maestro_api_models.models.data.ethernet_controller.model import (
    EthernetControllerModel,
)
from maestro_api_models.models.data.hard_drive.model import HardDriveModel
from maestro_api_models.models.data.inventory.pdu.model import SystemOutletMap
from maestro_api_models.models.data.kvm.model import KVMModel
from maestro_api_models.models.data.lab.model import LabModel
from maestro_api_models.models.data.lab_row_rack.model import LabRowRackModel
from maestro_api_models.models.data.memory_bank.model import MemoryBankModel
from maestro_api_models.models.data.motherboard.model import MotherboardModel
from maestro_api_models.models.data.system_extended_field.model import (
    SystemExtendedFieldModel,
)
from maestro_api_models.models.data.system_status.model import SystemStatusModel

from . import sample


class SystemModelBase(BaseModel):
    system_id: int | None = None
    created_date: datetime | None = None
    description: str | None = None
    inventory_id: str | None = None
    kvm_node_interface_label: str | None = None
    kvm_node_label: str | None = None
    lab_row_rack_id: int | None = None
    lab_rack_slot: int | None = None
    last_inventory_date: datetime | None = None
    mgt_mac_address: str | None = None
    serial_number: str | None = None
    sku: str | None = None
    updated_date: datetime | None = None
    uuid: str | None = None
    version: str | None = None

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={"example": sample.SYSTEM_MODEL_BASE_SAMPLE},
    )

    @field_validator("system_id")
    @classmethod
    def system_id_range(cls, v):
        if v is not None:
            validators.valid_db_id_signed(v)
        return v

    @field_validator("serial_number", "sku", "version")
    @classmethod
    def char_limit(cls, v):
        # VARCHAR(50) in Inventory DB
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=50)
        return v

    @field_validator("description")
    @classmethod
    def char_limit_1000(cls, v):
        # VARCHAR(1000) in Inventory DB
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=1000)
        return v

    @field_validator("created_date")
    @classmethod
    def datetime_utc_format(cls, v):
        if v is not None:
            validators.valid_datetime_utc(v, assume_utc_str=True)
        return v

    @field_validator("mgt_mac_address")
    @classmethod
    def mgt_mac_address_format(cls, v):
        if v is not None:
            validators.valid_mac_address(v)
        return v

    @field_validator("uuid")
    @classmethod
    def uuid_format(cls, v):
        if v is not None:
            validators.valid_uuid(v)
        return v

    @field_validator("inventory_id")
    @classmethod
    def inventory_id_char_limit(cls, v):
        # VARCHAR(64) in Inventory DB
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=64)
        return v


class SystemModelBasic(SystemModelBase):
    system_name: str | None = None
    lab: LabModel | None = None
    lab_row_rack: LabRowRackModel | None = None
    manufacturer: str | None = None
    mgt_ip_address: str | None = None
    name_model: str | None = None
    pools: List[str] | None = None
    bmc: BMCModel | None = None
    motherboard: MotherboardModel | None = None
    status: SystemStatusModel | None = None
    model_config = ConfigDict(json_schema_extra={"example": sample.SYSTEM_BASIC_SAMPLE})

    @field_validator("manufacturer", "name_model")
    @classmethod
    def char_limit(cls, v):
        # VARCHAR(50) in Inventory DB
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=50)
        return v

    @field_validator("mgt_ip_address")
    @classmethod
    def mgt_ip_address_format(cls, v):
        if v is not None:
            validators.valid_ip_address(v)
        return v

    @field_validator("pools")
    @classmethod
    def pool_names_format(cls, v):
        if v is not None:
            try:
                for pool_name in v:
                    validators.valid_pool_name(pool_name=pool_name)
            except ValueError as ve:
                raise ValueError(f"{ve} for each pool name in list")
        return v


class SystemModel(SystemModelBasic):
    bios: BIOSModel | None = None
    cpus: List[CPUModel] | None = None
    ethernet_controllers: List[EthernetControllerModel] | None = None
    hard_drives: List[HardDriveModel] | None = None
    kvm: KVMModel | None = None
    kvm_dongle_serial_number: str | None = None
    kvm_node_group: str | None = None
    ccsg_instance: CcsgBase | None = None
    link_partner_system_ids: List[int] | None = None
    memory_banks: List[MemoryBankModel] | None = None
    extended_fields: List[SystemExtendedFieldModel] | None = None
    pdus: SystemOutletMap | None = None
    power_options: List[PowerCommands] | None = None

    model_config = ConfigDict(
        json_schema_extra={"example": sample.SYSTEM_SAMPLE},
        from_attributes=True,
        extra="allow",
    )

    @computed_field
    @property
    def current_max_supported_pcie_gen(self) -> float | None:
        max_pcie_gen = self.motherboard.max_pcie_gen if self.motherboard else None

        if self.cpus:
            cpu_pcie_gens = [
                cpu.pcie_gen for cpu in self.cpus if cpu.pcie_gen is not None
            ]
            if cpu_pcie_gens:
                max_pcie_gen = (
                    min(cpu_pcie_gens)
                    if max_pcie_gen is None
                    else min(max_pcie_gen, min(cpu_pcie_gens))
                )

        if self.ethernet_controllers:
            ec_pcie_gens = [
                ec.current_pcie_generation
                for ec in self.ethernet_controllers
                if ec.current_pcie_generation is not None
            ]
            if ec_pcie_gens:
                max_pcie_gen = (
                    max(ec_pcie_gens)
                    if max_pcie_gen is None
                    else min(max_pcie_gen, max(ec_pcie_gens))
                )

        return max_pcie_gen

    @field_validator("kvm_dongle_serial_number")
    @classmethod
    def valid_max_char_count_15(cls, v):
        # VARCHAR(15) in Inventory DB
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=15)
            validators.valid_alphanumeric(v)
        return v

    @field_validator("kvm_node_group", "kvm_node_interface_label", "kvm_node_label")
    @classmethod
    def kvm_field_limit_and_chars(cls, v):
        # VARCHAR(255) in Inventory DB
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=255)
            validators.valid_kvm_field_characters(field=v)
        return v


class SystemInstanceModel(SystemModelBase):
    bios_date: datetime | None = None
    bios_vendor: str | None = None
    bios_version: str | None = None
    bmc_firmware_revision: str | None = None
    bmc_guid: str | None = None
    bmc_ip_address: str | None = None
    bmc_mac_address: str | None = None
    bmc_password: SecretStr | None = None
    bmc_username: str | None = None
    bmc_vlan: int | None = None
    motherboard_serial_number: str | None = None

    bmc_manufacturer_id: int | None = None
    chassis_id: int | None = None
    kvm_instance_id: int | None = None
    kvm_node_group_id: int | None = None
    manufacturer_id: int | None = None
    status_availability_id: int | None = None

    model_config = ConfigDict(
        json_schema_extra={"example": sample.SYSTEM_INSTANCE_MODEL_SAMPLE},
        from_attributes=True,
        validate_assignment=True,
        populate_by_name=True,
    )

    @field_validator(
        "bmc_manufacturer_id",
        "chassis_id",
        "kvm_instance_id",
        "kvm_node_group_id",
        "manufacturer_id",
        "status_availability_id",
    )
    @classmethod
    def valid_primary_key(cls, v):
        if v is not None:
            validators.valid_db_id_signed(v)
        return v

    @field_validator("bmc_vlan")
    @classmethod
    def valid_vlan(cls, v):
        if v is not None:
            validators.valid_vlan(v)
        return v

    @field_validator("bmc_mac_address")
    @classmethod
    def bmc_mac_address_format(cls, v):
        if v is not None:
            validators.valid_mac_address(v)
            v = v.lower()
        return v

    @field_validator("bmc_ip_address")
    @classmethod
    def bmc_ip_address_format(cls, v):
        if v is not None:
            validators.valid_ip_address(v)
        return v

    @field_validator("bmc_guid")
    @classmethod
    def bmc_guid_format(cls, v):
        if v is not None:
            validators.valid_uuid(v)
        return v

    @field_validator("bmc_firmware_revision")
    @classmethod
    def char_limit_10(cls, v):
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=10)
        return v

    @field_validator("bios_vendor", "bios_version")
    @classmethod
    def char_limit_50(cls, v):
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=50)
        return v
