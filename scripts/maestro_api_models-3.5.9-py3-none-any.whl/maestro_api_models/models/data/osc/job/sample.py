# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

from maestro_api_models.models.data.osc.role.sample import ROLE_MODEL_SAMPLE


JOB_MODEL_FULL_SAMPLE = {
    "id": "503c4e16-26fe-464d-bbae-f0fbe3405346",
    "awx_job_id": 23,
    "awx_job_status": "Pending",
    "ip_address": "10.10.5.6",
    "mac_address": "0F:F0:0F:F0:0F:F0",
    "roles": [ROLE_MODEL_SAMPLE],
}

JOB_MODEL_SAMPLE = {
    "id": "503c4e16-26fe-464d-bbae-f0fbe3405346",
    "awx_job_id": 23,
    "awx_job_status": "Unknown",
    "ip_address": "10.10.5.6",
    "mac_address": "0F:F0:0F:F0:0F:F0",
    "roles": [3, 8, 23],
}
