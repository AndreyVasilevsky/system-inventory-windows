# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict, UUID4, field_validator
from typing import List

# Local package imports
from maestro_api_models.common import validators
from maestro_api_models.models.data.osc.role.model import RoleModel
from . import sample


class JobModelBase(BaseModel):
    job_id: UUID4 | None = None
    awx_job_id: int | None = None
    awx_job_status: str | None = None
    ip_address: str | None = None
    mac_address: str | None = None

    @field_validator("mac_address")
    @classmethod
    def mgt_mac_address_format(cls, v):
        if v is not None:
            validators.valid_mac_address(v)
        return v

    @field_validator("ip_address")
    @classmethod
    def mgt_ip_address_format(cls, v):
        if v is not None:
            validators.valid_ip_address(v)
        return v


class JobModelFull(JobModelBase):
    roles: List[RoleModel] | None = None

    model_config = ConfigDict(
        json_schema_extra={"example": sample.JOB_MODEL_FULL_SAMPLE},
        from_attributes=True,
    )


class JobModel(JobModelBase):
    roles: List[int] | None = None

    model_config = ConfigDict(
        json_schema_extra={"example": sample.JOB_MODEL_SAMPLE},
        from_attributes=True,
    )
