# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

from pydantic import BaseModel, ConfigDict, field_validator
from typing import List

# Local package imports
from maestro_api_models.common import validators
from maestro_api_models.models.data.osc.role.model import RoleModel
from . import sample


class CustomizationModelBase(BaseModel):
    customization_id: int | None = None
    name: str | None = None
    owner_idsid: str | None = None
    is_public: bool | None = None
    shared_idsid: List[str] | None = None
    shared_group: List[str] | None = None

    model_config = ConfigDict(
        json_schema_extra={"example": sample.CUSTOMIZATION_MODEL_SAMPLE},
        from_attributes=True,
    )

    @field_validator("owner_idsid")
    @classmethod
    def idsid_string_length(cls, v):
        if v is not None:
            validators.valid_char_count(v, 8)
        return v

    @field_validator("shared_idsid")
    @classmethod
    def list_idsid_string_length(cls, v):
        if v is not None:
            for idsid in v:
                validators.valid_char_count(idsid, 8)
        return v


class CustomizationModelFull(CustomizationModelBase):
    roles: List[RoleModel] | None = None

    model_config = ConfigDict(
        json_schema_extra={"example": sample.CUSTOMIZATION_MODEL_SAMPLE}
    )


class CustomizationModel(CustomizationModelBase):
    roles: List[int] | None = None

    model_config = ConfigDict(
        json_schema_extra={"example": sample.CUSTOMIZATION_MODEL_FULL_SAMPLE}
    )
