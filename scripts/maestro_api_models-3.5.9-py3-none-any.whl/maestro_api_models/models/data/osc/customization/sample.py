# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

from maestro_api_models.models.data.osc.role.sample import ROLE_MODEL_SAMPLE

CUSTOMIZATION_MODEL_FULL_SAMPLE = {
    "id": 1,
    "name": "My Custom Playbook",
    "owner_idsid": "bscott",
    "is_public": 1,
    "shared_idsid": ["vhill2", "mvintel2"],
    "shared_group": ["OLE Development"],
    "roles": [ROLE_MODEL_SAMPLE],
}

CUSTOMIZATION_MODEL_SAMPLE = {
    "id": 1,
    "name": "My Custom Playbook",
    "owner_idsid": "bscott",
    "is_public": 1,
    "shared_idsid": ["vhill2", "mvintel2"],
    "shared_group": ["OLE Development"],
    "roles": [22, 56, 19, 13, 133],
}
