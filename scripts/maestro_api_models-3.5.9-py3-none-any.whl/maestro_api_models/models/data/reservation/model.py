# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Standard library imports
from datetime import datetime
import sys
from typing import List

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator

# Local package imports
from maestro_api_models.common.model_utils import get_model_fields
from maestro_api_models.common import validators
from . import sample


class ReservationTypes:
    """
    Defined and accepted values for system reservation types.

    - 'automation' (Reserved for automation tasks)
    - 'engineering' (Reserved for engineering tasks, such as development and validation)
    - 'maintenance-planned' (Reservation for planned maintenance of systems)
    - 'maintenance-unplanned' (Reservation for unplanned maintenance of systems)
    """

    AUTOMATION = "automation"
    ENGINEERING = "engineering"
    MAINTENANCE_PLANNED = "maintenance-planned"
    MAINTENANCE_UNPLANNED = "maintenance-unplanned"


class ReservationModelBasic(BaseModel):
    reservation_id: int | None = None
    user_idsids: List[str] | None = None
    primary_idsids: List[str] | None = None
    start_time: datetime | None = None
    end_time: datetime | None = None
    name: str | None = None

    @field_validator("start_time", "end_time")
    @classmethod
    def datetime_utc_format(cls, v):
        if v is not None:
            validators.valid_datetime_utc(v)
        return v

    model_config = ConfigDict(
        json_schema_extra={"example": sample.RES_MODEL_BASIC_SAMPLE},
        validate_assignment=True,
    )


class ReservationSystemModel(BaseModel):
    """
    ReservationSystemModel represents the model for a reservation system.

    NOTE: Created to avoid circular import issues with ReservationModel with SystemModel.
          Avoids a massive refactor in the process against all of the inventory codebase.

    Attributes:
        system_id (int): The unique identifier for the reservation system.
        system_name (str): The display system name of the reservation system.

    Config:
        json_schema_extra (dict): Additional JSON schema configuration, including an example.
        validate_assignment (bool): Ensures that assignments to fields are validated.
    """

    system_id: int | None = None
    system_name: str | None = None

    model_config = ConfigDict(
        json_schema_extra={"example": sample.RESERVATION_SYSTEM_MODEL_SAMPLE},
        validate_assignment=True,
    )


class ReservationModel(ReservationModelBasic):
    system_ids: List[int] | None = None
    reservation_type: str | None = None
    systems: List[ReservationSystemModel] | None = None

    message: str | None = None
    success: bool | None = None

    created_date: datetime | None = None
    last_modified_date: datetime | None = None

    @field_validator("system_ids")
    @classmethod
    def system_ids_range(cls, v):
        if v is not None:
            validators.valid_db_id_signed_list(v)
        return v

    @field_validator("reservation_id")
    @classmethod
    def reservation_ids_range(cls, v):
        if v is not None:
            validators.valid_db_id_unsigned(v)
        return v

    @field_validator("created_date", "last_modified_date")
    @classmethod
    def datetime_utc_format(cls, v):
        if v is not None:
            validators.valid_datetime_utc(v)
        return v

    @field_validator("reservation_type")
    @classmethod
    def valid_type(cls, v):
        if v is not None:
            valid_type_list = get_model_fields(
                sys.modules[__name__], "ReservationTypes"
            )
            if v not in valid_type_list:
                raise ValueError(f"invalid reservation type: {v}")
        return v

    model_config = ConfigDict(
        json_schema_extra={"example": sample.RES_MODEL_SAMPLE},
        validate_assignment=True,
    )


class ReservationsBySystemObject(BaseModel):
    system_id: int
    reservations: list[ReservationModel] = []

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "system_id": 11,
                "reservations": [sample.RES_MODEL_SAMPLE],
            }
        },
        validate_assignment=True,
    )
