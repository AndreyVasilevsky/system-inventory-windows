# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Standard library imports
from datetime import datetime, timedelta, timezone

RES_MODEL_BASIC_SAMPLE = {
    "reservation_id": 1,
    "user_idsids": ["zbrannigan", "pjfry"],
    "primary_idsids": ["zbrannigan"],
    "start_time": datetime.now(timezone.utc),
    "end_time": datetime.now(timezone.utc) + timedelta(minutes=15),
    "name": "My custom Reservation",
}

RES_MODEL_SAMPLE = {}
RES_MODEL_SAMPLE.update(RES_MODEL_BASIC_SAMPLE)
RES_MODEL_SAMPLE.update(
    {
        "system_ids": [0, 1, 2],
        "systems": [{"system_id": 0, "system_name": "My custom system"}],
        "reservation_type": "engineering",
        "message": "<used only by responses to report reservation information>",
        "success": True,
        "created_date": datetime.now(timezone.utc),
        "last_modified_date": datetime.now(timezone.utc) + timedelta(minutes=15),
    }
)

RESERVATION_SYSTEM_MODEL_SAMPLE = {
    "system_id": 10,
    "system_name": "My custom system",
}
