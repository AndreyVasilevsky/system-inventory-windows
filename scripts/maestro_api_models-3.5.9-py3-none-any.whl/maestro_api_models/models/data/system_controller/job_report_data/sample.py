# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

JOB_REPORT_SAMPLE = {
    "job_id": "508cfec6-9ef9-41e2-8e39-e7a36386535c",
    "job_report": """
__##_____##____###____########__######__########_########___#######___
__###___###___##_##___##_______##____##____##____##_____##_##_____##__
__####_####__##___##__##_______##__________##____##_____##_##_____##__
__##_###_##_##_____##_######____######_____##____########__##_____##__
__##_____##_#########_##_____________##____##____##___##___##_____##__
__##_____##_##_____##_##_______##____##____##____##____##__##_____##__
__##_____##_##_____##_########__######_____##____##_____##__#######___

###########--Maestro Inventory System Controller Report--#############

- System Controller Job ID: 1495550c-8bb2-4eb8-a31c-908af2a6d916

- System Controller System Failures: 1

- System Controller Job Result: SystemControllerStatusCodes.JOB_PARTIAL_SUCCESS

List of Failed Systems:
================================
- System Management IP Failures:
No reported system failures


================================
- Network Lookup Failures:
No reported system failures


================================
- OSD Host Data Lookup failures:
No reported system failures


================================
- Reboot Command Lookup Failures:
No reported system failures


================================
- OSD OS Change Failures:
No reported system failures


================================
- OS Boot Failures:
No reported system failures


================================
- OS Validation Failures:
No reported system failures
    """,
}
