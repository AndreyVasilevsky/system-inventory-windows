# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials, and your use of them is governed
# by the express license under which they were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit this software or the related documents
# without Intel's prior written permission.
#
# This software and the related documents are provided as is, with no express or implied warranties,
# other than those that are expressly stated in the License.

# Standard libraries
from typing import List

# Third Party Libraries
from pydantic import BaseModel, ConfigDict

from maestro_api_models.models.data.system.model import SystemModel

from . import sample


class SystemControlPayloadBase(BaseModel):
    system_data: List[SystemModel]

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.BASE_PAYLOAD_EXAMPLE,
        },
    )
