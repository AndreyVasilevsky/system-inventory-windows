# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials, and your use of them is governed
# by the express license under which they were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit this software or the related documents
# without Intel's prior written permission.
#
# This software and the related documents are provided as is, with no express or implied warranties,
# other than those that are expressly stated in the License.

# Standard Library

# Third Party Library
from pydantic import Field, ConfigDict

# Local Libraries
from maestro_api_models.models.data.system_controller.payload.base.model import (
    SystemControlPayloadBase,
)

from . import sample


class SystemInventoryAuditPayload(SystemControlPayloadBase):
    scan_system_topology: bool = Field(True, description="Flag to scan system topology")
    ignore_switch_link_partners: bool = Field(
        True, description="Flag to ignore switch link partners"
    )
    ignore_back_to_back_link_partners: bool = Field(
        False, description="Flag to ignore back to back link partners"
    )

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.SYSTEM_INVENTORY_AUDIT_EXAMPLE,
        },
    )
