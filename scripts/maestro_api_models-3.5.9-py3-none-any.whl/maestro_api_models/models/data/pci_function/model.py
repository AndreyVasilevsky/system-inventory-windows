# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Standard library imports
from typing import List
from re import match
import re

# Third party library imports
from pydantic import BaseModel, ConfigDict, Field, field_validator

# Local package imports
from maestro_api_models.models.data.inventory.topology.topology_map.model import (
    TopologyObject,
)
from maestro_api_models.common import validators
from ..pci_function import sample


class PCIFunctionModel(BaseModel):
    pci_function_id: int | None = Field(None, ge=1, alias="id")
    bus_device_function: str | None = None
    ip_address: str | None = None
    is_management_port: bool | None = None
    mac_address: str | None = None
    pcie_speed_current: str | None = None
    speed: str | None = None
    connected_devices: List[TopologyObject] | None = None

    model_config = ConfigDict(
        json_schema_extra={"example": sample.PCI_FUNCTION_SAMPLE},
        from_attributes=True,
        populate_by_name=True,
    )

    @field_validator("bus_device_function")
    @classmethod
    def bus_device_function_char_limit(cls, v):
        if v is not None:
            invalid = False
            # NOTE: do we need to have non-digits after the '.'?
            if (
                len(v) != 12
                or match("[\da-f]{4}:[\da-f]{2}:[\da-f]{2}.[\da-f]$", v.lower()) is None
            ):
                invalid = True
            if invalid:
                v = PCIFunctionModel._modify_bus_device_function(v)
        return v

    @classmethod
    def _modify_bus_device_function(cls, v):
        """Attempt to modify the input string to match the expected format.

        Args:
            v (_type_): input

        Raises:
            ValueError:

        Returns:
            _type_: Modified string
        """
        match = re.match(r"^([0-9A-Fa-f]{1,2}):([0-9A-Fa-f]{1,2}):(\d+)$", v)

        if not match:
            return "badb:ee:fb.0"

        hex1, hex2, number = match.groups()

        # Add leading zero if necessary
        hex1 = hex1.zfill(2).upper()
        hex2 = hex2.zfill(2).upper()

        # Format the output string
        formatted_string = f"0000:{hex1}:{hex2}.{number}"

        return formatted_string

    @field_validator("ip_address")
    @classmethod
    def ip_address_format(cls, v):
        if v is not None:
            validators.valid_ip_address(v)
        return v

    @field_validator("mac_address")
    @classmethod
    def mac_address_format(cls, v):
        if v is not None:
            validators.valid_mac_address(v)
        if v == "":
            v = None
        return v

    @field_validator("speed")
    @classmethod
    def speed_char_limit(cls, v):
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=10)
        return v

    @field_validator("pcie_speed_current")
    @classmethod
    def pci_speed_current_contains_number(cls, v):
        if v is not None:
            validators.begin_str_with_number(v)
        return v
