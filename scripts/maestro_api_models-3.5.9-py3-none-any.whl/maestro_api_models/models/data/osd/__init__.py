from .active_boot_type.model import ActiveBootTypeModel as OsdActiveBootType
from .bastion_host.model import BastionHostModel as OsdBastionHost
from .history.model import HistoryModelBase as OsdHistory
from .host.model import HostModel as OsdHost, HostBaseModel as OsdHostBase
from .host_kernel.model import HostKernelModel as OsdHostKernel
from .hw_profile.model import HwProfileModel as OsdHwProfile
from .kickstart.model import (
    KickstartModel as OsdKickstart,
    KickstartBaseModel as OsdKickstartBase,
)
from .os_base.model import OsBaseModel as OsdOs
from .os_diskless.model import DisklessOsModel as OsdDisklessOs
from .os_family.model import OsFamilyModel as OsdOsFamily
from .os_image_loader.model import ImageLoaderOsModel as OsdImageLoaderOs
from .os_iso.model import IsoOsModel as OsdIsoOs
from .os_type.model import OsTypeModel as OsdOsType
from .os_version.model import OsVersionModel as OsdOsVersion
from .refresh_mode.model import RefreshModeModel as OsdRefreshMode
from .storage_satellite.model import StorageSatelliteModel as OsdStorageSatellite
