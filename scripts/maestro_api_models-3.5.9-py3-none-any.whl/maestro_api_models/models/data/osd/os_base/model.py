# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

from typing import Dict, List

from pydantic import BaseModel

from maestro_api_models.models.data.osd.bastion_host.model import (
    BastionHostModel as BastionHost,
)
from maestro_api_models.models.data.osd.os_version.model import (
    OsVersionModel as OsVersion,
)


class OsBaseModel(BaseModel):
    id: int | None = None
    bastion_hosts: List[BastionHost] | None = None
    key: str | None = None
    os_info: Dict | None = None
    os_version: OsVersion | None = None
