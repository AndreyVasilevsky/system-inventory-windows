# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator

# Local package imports
from maestro_api_models.models.data.osd.active_boot_type.model import (
    ActiveBootTypeModel as ActiveBootType,
)
from maestro_api_models.models.data.osd.bastion_host.model import (
    BastionHostModel as BastionHost,
)
from maestro_api_models.models.data.osd.os_diskless.model import (
    DisklessOsModel as DisklessOs,
)
from maestro_api_models.models.data.osd.hw_profile.model import (
    HwProfileModel as HwProfile,
)
from maestro_api_models.models.data.osd.os_image_loader.model import (
    ImageLoaderOsModel as ImageLoaderOs,
)
from maestro_api_models.models.data.osd.os_iso.model import IsoOsModel as IsoOS
from maestro_api_models.models.data.osd.storage_satellite.model import (
    StorageSatelliteModel as StorageSatellite,
)
from maestro_api_models.models.data.osd.refresh_mode.model import (
    RefreshModeModel as RefreshMode,
)


class HostBaseModel(BaseModel):
    active_boot_type: ActiveBootType | None = None
    current_kickstart: int | None = None
    description: str | None = None
    host_name: str | None = None
    key: str | None = None
    refresh_mode: RefreshMode | None = None

    model_config = ConfigDict(use_enum_values=True)

    # Force the key to always be lowercase.
    @field_validator("key")
    @classmethod
    def check_key(cls, v):
        if not v:
            raise ValueError("OSD Host Key cannot be empty.")
        return v.lower()


class HostModel(HostBaseModel):
    ip: str | None = None
    active_os_key: str | None = None
    bastion_host: BastionHost | None = None
    diskless_os: DisklessOs | None = None
    diskless_storage_satellite: StorageSatellite | None = None
    disk_storage_satellite: StorageSatellite | None = None
    hw_profile: HwProfile | None = None
    id: int | None = None
    image_loader_os: ImageLoaderOs | None = None
    iso_os: IsoOS | None = None
    maestro_managed: bool | None = None
