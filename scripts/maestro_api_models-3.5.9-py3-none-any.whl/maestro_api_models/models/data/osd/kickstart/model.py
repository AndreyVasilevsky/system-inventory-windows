# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Standard package imports
from typing import Optional

# Third party library imports
from pydantic import BaseModel


class KickstartBaseModel(BaseModel):
    id: Optional[int] = None
    name: Optional[str] = None
    default: Optional[bool] = None
    os_family_id: Optional[int] = None
    os_type_id: Optional[int] = None
    os_major_version: Optional[str] = None
    os_minor_version: Optional[str] = None
    os_patch_version: Optional[str] = None
    os_hot_fix_version: Optional[str] = None


class KickstartModel(KickstartBaseModel):
    automatic_script: Optional[str] = None
    manual_script: Optional[str] = None
