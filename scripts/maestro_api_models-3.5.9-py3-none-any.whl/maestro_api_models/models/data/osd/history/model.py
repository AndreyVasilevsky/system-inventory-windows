# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party packages
from pydantic import BaseModel, computed_field

# Local packages
from maestro_api_models.models.data.osd.host.model import HostModel as Host
from maestro_api_models.models.data.osd.os_base.model import OsBaseModel as Os


class HistoryModelBase(BaseModel):
    id: int | None = None
    host: Host | None = None
    os: Os | None = None
    os_state: str | None = None
    refresh_on_boot: bool | None = None
    time_of_last_boot: str | None = None
    curr_kickstart_id: int | None = None
    cached_diskless_os_id: int | None = -1

    @computed_field
    @property
    def boot_type(self) -> str:
        if self.curr_kickstart_id:
            return "ISO"
        elif self.cached_diskless_os_id == -1:
            return "IMAGE LOADER"
        else:
            return "DISKLESS"
