# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict, model_validator
from typing import Union

# Local package imports

from . import sample
from maestro_api_models.models.metadata.schema.model import SchemaMetadataModel
from maestro_api_models.models.data.rsa_key.model import RsaKey

# Import Shared Common Libraries

from maestro_api_models.common.data_validators.credential_validators import (
    valid_user_linux,
    valid_pass,
)
from maestro_api_models.common.data_validators.certificate_validators import (
    CertificateValidators,
)


class SshUserModel(BaseModel):
    ssh_user: str
    ssh_password: str | None = None
    ssh_priv_key: Union[str, RsaKey] | None = None

    schema_metadata: SchemaMetadataModel | None = None

    model_config = ConfigDict(
        json_schema_extra={"example": sample.SSH_USER_CONFIGURATION_SAMPLE},
        arbitrary_types_allowed=True,
        from_attributes=True,
    )

    @model_validator(mode="before")
    def check_values(cls, v):
        """Check that the SSH User Data is valid."""
        if not isinstance(v, dict):
            raise ValueError("SSH User Data cannot be blank. ")

        try:
            valid_user_linux(v["ssh_user"], False)
        except ValueError as err:
            raise err

        if "ssh_password" in v:
            try:
                valid_pass(v["ssh_password"], False)
            except ValueError as err:
                raise err

        elif "ssh_priv_key" in v:
            if not CertificateValidators.string_is_private_key(v["ssh_priv_key"]):
                raise ValueError("Provided SSH Certificate is not valid.")
        else:
            raise ValueError(
                "Cannot have an empty Password and SSH Private Key, one must be used."
            )

        return v

    def json(self, **kwargs):
        # Convert Paramiko RSA key to string representation if it exists
        if type(self.ssh_priv_key) is RsaKey:
            rsa_key_str = self.ssh_priv_key.json(**kwargs)
        else:
            rsa_key_str = self.ssh_priv_key

        # Call the parent class's json() method and modify the output
        json_dict = super().json(**kwargs)
        json_dict["rsa_key"] = rsa_key_str
        return json_dict
