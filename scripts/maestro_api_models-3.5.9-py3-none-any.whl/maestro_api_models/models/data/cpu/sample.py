# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

CPU_SAMPLE = {
    "cpu_id": 1,
    "core_count": 8,
    "family": 86,
    "max_speed_mhz": 1500,
    "min_speed_mhz": 850,
    "model": 7,
    "product": "Cyberdyne T800 (Sample)",
    "socket_designation": "CPU1",
    "socket_type": "Socket LGA3647-1",
    "stepping": 3,
    "thread_count": 8,
    "manufacturer": "Cyberdyne Incorporated (Sample)",
    "codename": "Wolfspace",
    "pcie_gen": 3.1,
    "silicon_family_name": "Broadwell",
}
