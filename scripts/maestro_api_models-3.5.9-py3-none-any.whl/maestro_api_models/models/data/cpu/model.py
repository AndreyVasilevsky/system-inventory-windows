# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator

# Local package imports
from maestro_api_models.common import validators
from . import sample


class CPUModel(BaseModel):
    cpu_id: int | None = None
    core_count: int | None = None
    family: int | None = None
    max_speed_mhz: int | None = None
    min_speed_mhz: int | None = None
    model: int | None = None
    product: str | None = None
    socket_designation: str | None = None
    socket_type: str | None = None
    stepping: int | None = None
    thread_count: int | None = None
    manufacturer: str | None = None
    codename: str | None = None
    pcie_gen: float | None = None
    silicon_family_name: str | None = None

    model_config = ConfigDict(json_schema_extra={"example": sample.CPU_SAMPLE})

    @field_validator("cpu_id")
    @classmethod
    def cpu_id_range(cls, v):
        if v is not None:
            validators.valid_db_id_signed(v)
        return v

    @field_validator(
        "core_count",
        "family",
        "max_speed_mhz",
        "min_speed_mhz",
        "model",
        "stepping",
        "thread_count",
    )
    @classmethod
    def positive_integer(cls, v):
        if v is not None:
            validators.positive_number(v)
        return v

    @field_validator("manufacturer", "product", "socket_designation", "socket_type")
    @classmethod
    def char_limit_50(cls, v):
        # VARCHAR(50) in Inventory DB
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=50)
        return v

    def __hash__(self) -> int:
        return hash((self.cpu_id, self.family, self.model, self.stepping))

    @field_validator("codename", "silicon_family_name")
    @classmethod
    def char_limit_128(cls, v):
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=128)
        return v
