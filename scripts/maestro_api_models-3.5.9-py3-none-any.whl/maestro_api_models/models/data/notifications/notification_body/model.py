# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Standard Library Imports
from typing import List

# Third party library imports
from pydantic import BaseModel, ConfigDict, model_validator, field_validator

# Local package imports
from maestro_api_models.common.validators import valid_emails
from .sample import NOTIFICATION_SAMPLE


class NotificationBody(BaseModel):
    subject: str
    to: List[str] | None = None
    cc: List[str] | None = None
    bcc: List[str] | None = None
    body: str

    model_config = ConfigDict(
        json_schema_extra={"example": NOTIFICATION_SAMPLE},
        arbitrary_types_allowed=True,
        from_attributes=True,
    )

    @model_validator(mode="before")
    def validate_at_least_one_recipient(cls, values):
        if (
            not values.get("to") and not values.get("cc") and not values.get("bcc")
        ) or (
            values.get("to") == []
            and values.get("cc") == []
            and values.get("bcc") == []
        ):
            raise ValueError("At least one recipient must be specified")

        return values

    @field_validator("to", "cc", "bcc")
    @classmethod
    def email_addresses_valid(cls, v):
        if v is not None:
            valid_emails(v)
        return v
