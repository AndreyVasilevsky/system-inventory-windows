# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Local Libraries #
from maestro_api_models.models.data.lab_row_rack.sample import LAB_ROW_RACK_SAMPLE
from maestro_api_models.models.data.lab.sample import LAB_SAMPLE
from maestro_api_models.models.data.manufacturer.sample import MANUFACTURER_SAMPLE
from maestro_api_models.models.data.inventory.port.sample import PORT_FORM_FACTOR
from maestro_api_models.models.data.inventory.port.sample import PORT_SPEED


SWITCH = {
    "switch_model_id": 1,
    "manufacturer_id": 2,
    "model_name": "Switch Model X",
    "obsolete": False,
    "port_count": 24,
}


SWITCH_INSTANCE = {
    "switch_instance_id": 1,
    "switch_id": 2,
    "lab_row_rack_id": 3,
    "primary_firmware_version": "1.0.0",
    "secondary_firmware_version": "1.0.1",
    "status_availability_id": 1,
    "inventory_id": "INV123",
    "serial_number": "SN123",
    "mgt_mac_address": "00:0a:95:9d:68:16",
    "link_mac_address": "00:0a:95:9d:68:17",
    "mgt_ip_address": "192.168.1.1",
    "mgt_user": "admin",
    "mgt_password": "password",
    "snmp_user": "snmp_user",
    "snmp_password": "snmp_password",
    "snmp_protocol_vers": "2c",
}


SWITCH_PORT_INSTANCE = {
    "switch_port_instance_id": 1,
    "physical_port": 2,
    "logical_port": "Gi1/0/1",
    "max_port_speed": 1000,
    "port_form_factor_id": 145,
    "switch_instance_id": 3,
}

SWITCH_LOGICAL_PORT_INSTANCE = {
    "logical_port": "Gi1/0/1",
    "connected_devices": [
        {
            "device_id": 1,
            "device_type": "ethernet_controller_port_instance",
            "port_instance_id": 1,
        },
        {"device_id": 2, "device_type": "switch_port_instance", "port_instance_id": 2},
    ],
}

SWITCH_PORT_INSTANCE_FULL_DETAILS = {
    "physical_port": 2,
    "logical_ports": [SWITCH_LOGICAL_PORT_INSTANCE, SWITCH_LOGICAL_PORT_INSTANCE],
    "max_port_speed": 1000,
    "port_form_factor": "1000Base-T",
    "supported_speeds": [PORT_SPEED, PORT_SPEED],
}


SWITCH_LOCATION = {"lab": LAB_SAMPLE, "lab_row_rack": LAB_ROW_RACK_SAMPLE}


SWITCH_INSTANCE_FULL_DETAIL = {
    "switch_instance": SWITCH_INSTANCE,
    "switch": SWITCH,
    "switch_location": SWITCH_LOCATION,
}


SWITCH_FULL_DETAIL = {"switch": SWITCH, "manufacturer": MANUFACTURER_SAMPLE}


SWITCH_MODEL_PORT_TYPE_SUPPORT = {
    "switch_model_port_type_support_id": 1,
    "switch_model_id": 2,
    "switch_port_form_factor_id": 3,
    "port_count": 48,
}


SWITCH_PORT_INSTANCE_SUPPORTED_SPEEDS = {
    "switch_port_instance_supported_speed_id": 1,
    "switch_port_instance_id": 2,
    "port_speed_id": 3,
}


SWITCH_SUPPORTED_PORT_TYPE = {
    "form_factor": PORT_FORM_FACTOR,
    "port_count": 48,
}


SWITCH_PORT_MAP = {
    "ports": [SWITCH_PORT_INSTANCE_FULL_DETAILS],
}
