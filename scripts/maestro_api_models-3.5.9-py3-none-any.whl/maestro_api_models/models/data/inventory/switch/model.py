# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Standard Libraries #
from typing import List

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator, Field

# Local Libraries #
from maestro_api_models.models.data.inventory.topology.topology_map.model import (
    TopologyObject,
)
from maestro_api_models.common.data_validators.network_validators import (
    valid_mac_address,
    valid_ip_address,
)
from maestro_api_models.common.data_validators.credential_validators import (
    valid_pass,
    valid_user_linux,
)
from maestro_api_models.models.data.lab_row_rack.model import LabRowRackModel
from maestro_api_models.models.data.lab.model import LabModel
from maestro_api_models.models.data.manufacturer.model import ManufacturerModel
from maestro_api_models.models.data.inventory.port.model import (
    PortFormFactor,
    PortSpeed,
)

from . import sample


class Switch(BaseModel):
    switch_model_id: int = Field(
        None, alias="id", description="The primary key for the switch."
    )
    manufacturer_id: int = Field(
        None, description="The foreign key for the manufacturer of the switch."
    )
    model_name: str = Field(None, description="The model name of the switch.")
    obsolete: bool = Field(
        False, description="A boolean indicating whether the switch is obsolete."
    )
    port_count: int = Field(32, description="The number of ports on the switch.")

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.SWITCH,
        },
    )


class SwitchInstance(BaseModel):
    switch_instance_id: int = Field(
        None, alias="id", description="The primary key for the switch instance."
    )
    switch_id: int = Field(None, description="The foreign key for the switch.")
    lab_row_rack_id: int = Field(
        None, description="The foreign key for the lab row rack."
    )
    primary_firmware_version: str | None = None
    secondary_firmware_version: str | None = None
    status_availability_id: int | None = 1
    inventory_id: str | None = None
    serial_number: str | None = None
    mgt_mac_address: str | None = None
    link_mac_address: str | None = None
    mgt_ip_address: str | None = None
    mgt_user: str | None = None
    mgt_password: str | None = None
    snmp_user: str | None
    snmp_password: str | None
    snmp_protocol_vers: str | None

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        arbitrary_types_allowed=True,
        json_schema_extra={
            "example": sample.SWITCH_INSTANCE,
        },
    )

    @field_validator("mgt_mac_address")
    @classmethod
    def valid_mgt_mac_address(cls, v):
        """Verify that switch management MAC address is a valid.

        Raises:
            ValueError
        """
        if v is not None:
            if not valid_mac_address(v):
                raise ValueError(
                    "Switch management MAC address must be a valid mac address value."
                )
            return v

    @field_validator("link_mac_address")
    @classmethod
    def valid_link_mac_address(cls, v):
        """Verify that switch link MAC address is a valid.

        Raises:
            ValueError
        """
        if v is not None:
            if not valid_mac_address(v):
                raise ValueError(
                    "Switch link MAC address must be a valid mac address value."
                )
            return v

    @field_validator("mgt_ip_address")
    @classmethod
    def valid_mgt_ip_address(cls, v):
        """Verify that switch management IP address is a valid IPv4 value.

        Raises:
            ValueError
        """
        if v is not None:
            if not valid_ip_address(v):
                raise ValueError(f"`{v}` is not a valid IPv4 Address.")
            return v

    @field_validator("mgt_user")
    @classmethod
    def valid_mgt_user(cls, v):
        """Verify that switch management user is a valid.

        Raises:
            ValueError
        """
        if v is not None:
            valid_user_linux(v, False)
            return v

    @field_validator("mgt_password")
    @classmethod
    def valid_mgt_password(cls, v):
        """Verify that switch management password is a valid.

        Raises:
            ValueError
        """
        if v is not None:
            valid_pass(v, False)
            return v

    @field_validator("snmp_user")
    @classmethod
    def valid_snmp_user(cls, v):
        """Verify that switch SNMP user is a valid.

        Raises:
            ValueError
        """
        if v is not None:
            valid_user_linux(v, False)
            return v

    @field_validator("snmp_password")
    @classmethod
    def valid_snmp_password(cls, v):
        """Verify that switch SNMP password is a valid.

        Raises:
            ValueError
        """
        if v is not None:
            valid_pass(v, False)
            return v


class SwitchPortInstance(BaseModel):
    switch_port_instance_id: int = Field(
        None, alias="id", description="The primary key for the switch port instance."
    )
    physical_port: int = Field(description="The physical port number.")
    logical_port: str = Field(description="The logical port identifier.")
    max_port_speed: int = Field(100, description="The maximum port speed in megabits.")
    port_form_factor_id: int = Field(
        description="The foreign key for the port form factor."
    )
    switch_instance_id: int = Field(
        description="The foreign key for the switch instance."
    )

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.SWITCH_PORT_INSTANCE,
        },
    )


class SwitchSupportedPortType(BaseModel):
    form_factor: PortFormFactor
    port_count: int

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.SWITCH_SUPPORTED_PORT_TYPE,
        },
    )


class SwitchLocation(BaseModel):
    lab: LabModel
    lab_row_rack: LabRowRackModel

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.SWITCH_LOCATION,
        },
    )


class SwitchModelFullDetail(BaseModel):
    switch: Switch = Field(alias="switch_model")
    manufacturer: ManufacturerModel = Field(alias="switch_manufacturer")
    switch_model_port_type_support: List[SwitchSupportedPortType] | None = []

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.SWITCH_FULL_DETAIL,
        },
    )


class SwitchInstanceFullDetails(BaseModel):
    switch_instance: SwitchInstance
    switch_model: SwitchModelFullDetail
    switch_location: SwitchLocation

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.SWITCH_INSTANCE_FULL_DETAIL,
        },
    )


class SwitchLogicalPortInstance(BaseModel):
    logical_port: str
    connected_devices: List[TopologyObject] | None = []

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.SWITCH_LOGICAL_PORT_INSTANCE,
        },
    )


class SwitchPortInstanceFullDetails(BaseModel):
    physical_port: int
    logical_ports: List[SwitchLogicalPortInstance]
    max_port_speed: int
    port_form_factor: str = Field(alias="form_factor")
    supported_speeds: List[PortSpeed] | None = []

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.SWITCH_PORT_INSTANCE_FULL_DETAILS,
        },
    )


class SwitchPortMap(BaseModel):
    ports: List[SwitchPortInstanceFullDetails]

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.SWITCH_PORT_MAP,
        },
    )


class SwitchModelPortTypeSupport(BaseModel):
    switch_model_port_type_support_id: int = Field(None, alias="id")
    switch_model_id: int
    switch_port_form_factor_id: int
    port_count: int

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.SWITCH_MODEL_PORT_TYPE_SUPPORT,
        },
    )

    @field_validator("port_count")
    @classmethod
    def valid_port_count(cls, v):
        """Verify that the port count is a positive integer.

        Raises:
            ValueError
        """
        if v < 1:
            raise ValueError("Port count must be a positive integer.")
        return v


class SwitchPortInstanceSupportedSpeeds(BaseModel):
    switch_port_instance_support_speed_id: int = Field(None, alias="id")
    switch_port_instance_id: int
    port_speed_id: int

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.SWITCH_PORT_INSTANCE_SUPPORTED_SPEEDS,
        },
    )
