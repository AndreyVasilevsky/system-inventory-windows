# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
import json
from pydantic import BaseModel, field_validator, Json, model_validator

# Local package imports
from maestro_api_models.common import validators


class ExtendedFieldNameModel(BaseModel):
    extended_field_name_id: int | None = None
    name: str | None = None
    note: str | None = None
    encrypted: bool | None = None
    searchable: bool | None = None
    user_override: bool | None = None
    visible: bool | None = None
    config: Json | None = None

    @field_validator("extended_field_name_id")
    @classmethod
    def valid_db_id(cls, v):
        if v is not None:
            validators.valid_db_id_signed(v)
        return v

    @field_validator("name")
    @classmethod
    def format_name(cls, v):
        if v is not None:
            v = v.upper()
            v = v.replace(" ", "_").replace("-", "_")
            # raise if v starts with a number
            validators.begin_str_with_alpha(v)
            validators.valid_alphanumeric(v, ["_"])
        return v

    @field_validator("name")
    @classmethod
    def char_limit_1_to_255(cls, v):
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=255, min_len=1)
        return v

    @field_validator("note")
    @classmethod
    def char_limit_255(cls, v):
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=255)
        return v

    @model_validator(mode="before")
    def before_validation(cls, data):
        if isinstance(data, str):
            data = json.loads(data)
        if "config" in data and data["config"]:
            data["config"] = cls.format_config(data["config"])
        return data

    @classmethod
    def format_config(cls, v):
        if v:
            try:
                v = json.dumps(json.loads(v))
            except Exception:
                try:
                    v = json.dumps(json.loads(str(v).replace("'", '"')))
                except Exception:
                    raise ValueError("Failed to load 'config' as json")
        return v
