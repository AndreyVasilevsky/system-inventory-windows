# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Standard Libraries #
from pydantic import BaseModel, ConfigDict


# Local Libraries #
from maestro_api_models.constants.topology_device_types import TopologyDeviceTypes
from . import sample


class TopologyMap(BaseModel):
    link_partner_1_id: int
    link_partner_1_type: int
    link_partner_2_id: int
    link_partner_2_type: int

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.TOPOLOGY_MAP_SAMPLE,
        },
    )


class TopologyPortObject(BaseModel):
    port_device_type: TopologyDeviceTypes
    port_instance_id: int
    port_identifier: str
    port_short_name: str

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.TOPOLOGY_PORT_OBJECT_SWITCH_SAMPLE,
        },
    )


class TopologyObject(BaseModel):
    device_id: int
    device_type: TopologyDeviceTypes
    port_object: TopologyPortObject

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.TOPOLOGY_OBJECT_SAMPLE,
        },
    )
