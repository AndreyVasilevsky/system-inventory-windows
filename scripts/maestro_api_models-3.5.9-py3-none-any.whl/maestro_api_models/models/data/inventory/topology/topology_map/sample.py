# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Standard Libraries #

# Local Libraries #
from maestro_api_models.constants.topology_device_types import TopologyDeviceTypes


TOPOLOGY_MAP_SAMPLE = {
    "link_partner_1_id": 1,
    "link_partner_1_type": 1,
    "link_partner_2_id": 2,
    "link_partner_2_type": 1,
}


TOPOLOGY_PORT_OBJECT_SWITCH_SAMPLE = {
    "port_device_type": TopologyDeviceTypes.SWITCH_INSTANCE,
    "port_instance_id": 1,
    "port_identifier": "Port 1",
    "port_short_name": "Gi1/0/1",
}


TOPOLOGY_PORT_OBJECT_ETHERNET_SAMPLE = {
    "port_device_type": TopologyDeviceTypes.ETHERNET_CONTROLLER_INSTANCE,
    "port_instance_id": 1,
    "port_identifier": "0000:53:00.0",
    "port_short_name": "X550-T2",
}


TOPOLOGY_OBJECT_SAMPLE = {
    "device_id": 1,
    "device_type": TopologyDeviceTypes.SYSTEM_INSTANCE,
    "port_object": TOPOLOGY_PORT_OBJECT_SWITCH_SAMPLE,
}
