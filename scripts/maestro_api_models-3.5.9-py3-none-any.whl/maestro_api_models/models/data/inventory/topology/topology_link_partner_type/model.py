# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Standard Libraries #
from pydantic import BaseModel, ConfigDict, Field


# Local Libraries #
from . import sample


class TopologyLinkPartnerType(BaseModel):
    topology_link_partner_type_id: int = Field(None, alias="id")
    topology_type: str

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.TOPOLOGY_LINK_PARTNER_TYPE_SAMPLE,
        },
    )
