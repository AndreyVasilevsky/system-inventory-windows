# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

from maestro_api_models.models.data.lab.sample import LAB_SAMPLE
from maestro_api_models.models.data.lab_row_rack.sample import LAB_ROW_RACK_SAMPLE
from maestro_api_models.models.data.manufacturer.sample import MANUFACTURER_SAMPLE

PDU = {
    "manufacturer_id": 12,
    "model_name": "PX2-5532",
    "outlet_count": 24,
    "obsolete": False,
}

PDU_INSTANCE = {
    "pdu_id": 128,
    "lab_row_rack_id": 15,
    "serial_number": "ASSDASAS202030230",
    "firmware_version": "1.0.0",
    "mac_address": "aa:bb:cc:dd:ee:ff",
    "ip_address": "192.168.1.20",
    "snmp_user": "pdu238_admin",
    "snmp_password": "somemagicalpasswordvalue",
    "snmp_protocol_vers": "V1",
    "read_write_community_key": "7asd977as6d8as6d08asd67asd",
    "read_only_community_key": "asd976as5d4as75d4a9s8d-9asd-8as9d679as6d9asd",
    "api_user": "pduRestAPIUser",
    "api_password": "pduRestApiUserPassword",
    "api_url": "/v1/pdu/control_api",
}

PDU_LOCATION = {
    "lab": LAB_SAMPLE,
    "lab_row_rack": LAB_ROW_RACK_SAMPLE,
}

PDU_INSTANCE_FULL_DETAIL = {
    "pdu_instance": PDU_INSTANCE,
    "pdu_model": PDU,
    "pdu_location": PDU_LOCATION,
    "pdu_manufacturer": MANUFACTURER_SAMPLE,
}

SYSTEM_PDU_MAP = {
    "pdu": PDU_INSTANCE_FULL_DETAIL,
    "outlets": [2, 4, 5, 6],
}

SYSTEM_OUTLET_MAP = {"system_outlet_map": [SYSTEM_PDU_MAP]}

SYSTEM_INSTANCE_PDU_OUTLET_MAP = {
    "system_instance_id": 10,
    "pdu_instance_id": 128,
    "outlet_number": [2, 4, 5, 6] or 2,
}
