# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator, Field
from typing import List, Final
from maestro_api_models.common.data_validators.network_validators import (
    valid_mac_address,
    valid_ip_address,
)
from maestro_api_models.models.data.lab_row_rack.model import LabRowRackModel
from maestro_api_models.models.data.lab.model import LabModel
from maestro_api_models.models.data.manufacturer.model import ManufacturerModel
from . import sample

PDU_OUTLET_MAX: Final = 48


class Pdu(BaseModel):
    pdu_id: int = Field(None, alias="id")
    manufacturer_id: int
    model_name: str
    outlet_count: int
    obsolete: bool | None = False

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.PDU,
        },
    )

    @field_validator("outlet_count")
    @classmethod
    def valid_outlet_count(cls, v):
        """Verify that the Outlet Count is a positive value and does not exceed the PDU_OUTLET_MAX.

        Raises:
            ValueError
        """
        if (not v) or (v < 1) or (v > PDU_OUTLET_MAX):
            raise ValueError(
                f"PDU Outlet Count must fall between 1 and {PDU_OUTLET_MAX}"
            )

        return v


class PduInstance(BaseModel):
    pdu_instance_id: int = Field(None, alias="id")
    pdu_id: int
    lab_row_rack_id: int
    serial_number: str
    firmware_version: str | None = "unknown"
    mac_address: str
    ip_address: str
    snmp_user: str | None = None
    snmp_password: str | None = None
    snmp_protocol_vers: str | None = None
    read_write_community_key: str | None = None
    read_only_community_key: str | None = None
    api_user: str | None = None
    api_password: str | None = None
    api_url: str | None = None

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.PDU_INSTANCE,
        },
    )

    @field_validator("mac_address")
    @classmethod
    def valid_mac_address(cls, v):
        """Verify that PDU mac address is a valid.

        Raises:
            ValueError
        """
        if not valid_mac_address(v):
            raise ValueError("PDU mac address must be a valid mac address value.")
        return v

    @field_validator("ip_address")
    @classmethod
    def valid_ip_address(cls, v):
        """Verify that PDU IP address is a valid IPv4 value.

        Raises:
            ValueError
        """
        if not valid_ip_address(v):
            raise ValueError(f"`{v}` is not a valid IPv4 Address.")
        return v


class SystemInstancePduOutletMap(BaseModel):
    system_instance_id: int
    pdu_instance_id: int
    outlet_number: List

    model_config = ConfigDict(
        from_attributes=True,
        json_schema_extra={
            "example": sample.SYSTEM_INSTANCE_PDU_OUTLET_MAP,
        },
    )


class PduLocation(BaseModel):
    lab: LabModel
    lab_row_rack: LabRowRackModel

    model_config = ConfigDict(from_attributes=True)


class PduInstanceFullDetail(BaseModel):
    pdu_instance: PduInstance
    pdu_model: Pdu
    pdu_location: PduLocation
    pdu_manufacturer: ManufacturerModel

    model_config = ConfigDict(from_attributes=True)


class PduModelFullDetail(BaseModel):
    pdu: Pdu = Field(None, alias="pdu_model")
    manufacturer: ManufacturerModel = Field(None, alias="pdu_manufacturer")

    model_config = ConfigDict(from_attributes=True)


class SystemPduMap(BaseModel):
    pdu: PduInstanceFullDetail
    outlets: List[int]

    model_config = ConfigDict(from_attributes=True)


class SystemOutletMap(BaseModel):
    system_outlet_map: List[SystemPduMap] | None = None

    model_config = ConfigDict(from_attributes=True)
