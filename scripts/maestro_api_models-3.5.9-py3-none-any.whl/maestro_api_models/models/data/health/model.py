# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third Party Package Imports
from pydantic import BaseModel, ConfigDict

# Local Package Imports
from maestro_api_models.constants import HealthStatus, ProcessHealthStatus


class Health(BaseModel):
    """A class to represent the response of the health check endpoint."""

    status: HealthStatus

    model_config = ConfigDict(
        validate_assignment=True,
        json_schema_extra={
            "example": {
                "status": "UP",
            }
        },
    )


class HealthProcess(BaseModel):
    """A class to represent the response of the health check endpoint."""

    status: ProcessHealthStatus
    consecutive_errors: int = 0

    model_config = ConfigDict(
        validate_assignment=True,
        json_schema_extra={
            "example": {
                "status": "starting",
                "consecutive_errors": 0,
            }
        },
    )
