# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
import math
from pydantic import BaseModel, ConfigDict, computed_field, field_validator, Field

# Local package imports
from maestro_api_models.common import validators
from maestro_api_models.models.data.pci_function.model import PCIFunctionModel
from maestro_api_models.common.convert import Convert
from . import sample


class EthernetControllerFilterModel(BaseModel):
    ethernet_controller_id: int | None = Field(None, ge=1, alias="id")
    branding_name: str | None = Field(None, max_length=100)
    vendor_id: str | None = Field(None, alias="vendor_id_code")
    device_id: str | None = Field(None, alias="device_id_code")
    sub_vendor_id: str | None = Field(None, alias="sub_vendor_id_code")
    sub_vendor_device_id: str | None = Field(None, alias="sub_vendor_device_id_code")
    revision: str | None = Field(None, max_length=100)
    codename: str | None = Field(None, max_length=128)
    silicon_name: str | None = Field(None, max_length=128)
    silicon_family_name: str | None = Field(None, max_length=128)

    model_config = ConfigDict(
        json_schema_extra={"example": sample.ETHERNET_CONTROLLER_FILTER_MODEL_SAMPLE},
        from_attributes=True,
        populate_by_name=True,
    )


class EthernetControllerInstanceFilterModel(EthernetControllerFilterModel):
    ethernet_controller_instance_id: int | None = Field(None, ge=1, alias="id")
    ethernet_controller_id: int | None = Field(None, ge=1)
    system_instance_id: int | None = Field(None, ge=1)
    pcie_generation: float | None = Field(None, ge=1.0)

    @computed_field
    @property
    def pcie_speed_max(self) -> float | None:
        if self.pcie_generation is None:
            return None
        if self.pcie_generation >= 1.0 and self.pcie_generation < 2.0:
            return 2.5
        elif self.pcie_generation == 2.0 and self.pcie_generation < 3.0:
            return 5.0
        else:
            return 2 ** math.floor(self.pcie_generation)

    model_config = ConfigDict(
        json_schema_extra={
            "example": sample.ETHERNET_CONTROLLER_INSTANCE_FILTER_MODEL_SAMPLE
        },
        from_attributes=True,
        populate_by_name=True,
    )


class EthernetControllerModel(BaseModel):
    ethernet_controller_instance_id: int | None = Field(None, ge=1, alias="id")
    ethernet_controller_id: int | None = Field(None, ge=1)
    branding_name: str | None = Field(None, max_length=100)
    cable_type: str | None = Field(None, max_length=50)
    device_id: str | None = Field(None, alias="device_id_code")
    firmware: str | None = Field(None, max_length=50)
    numa_node: int | None = Field(None, ge=0, alias="numa")
    nvm_version: str | None = Field(None, max_length=100)
    pcie_speed_max: str | None = Field(None, alias="max_pcie_width")
    pcie_width_current: int | None = Field(None, ge=0, alias="pcie_width")
    pcie_width_max: int | None = Field(None, ge=0, alias="max_pcie_speed")
    pcie_functions: list[PCIFunctionModel] | None = None
    revision: str | None = Field(None, max_length=100)
    slot: str | None = Field(None, max_length=100, alias="pcie_slot")
    subvendor_device_id: str | None = Field(None, alias="sub_vendor_device_id_code")
    subvendor_id: str | None = Field(None, alias="sub_vendor_id_code")
    vendor_id: str | None = Field(None, alias="vendor_id_code")
    major_device_name: str | None = Field(None, max_length=128, alias="device_name")
    minor_device_name: str | None = Field(None, max_length=128, alias="sub_device_name")
    vendor_name: str | None = Field(None, max_length=128)
    subvendor_name: str | None = Field(None, max_length=128)
    codename: str | None = Field(None, max_length=128)
    silicon_family_name: str | None = Field(None, max_length=128)
    silicon_name: str | None = Field(None, alias="codename")

    model_config = ConfigDict(
        json_schema_extra={"example": sample.ETHERNET_CONTROLLER_SAMPLE},
        from_attributes=True,
        populate_by_name=True,
    )

    @computed_field
    @property
    def current_pcie_generation(self) -> float | None:
        # pcie_speed_max is required for value computation
        if self.pcie_speed_max is None:
            return None

        try:
            pcie_speed = Convert.pcie_speed_to_float(self.pcie_speed_max)
            if pcie_speed == 2.5:
                return 1.0
            elif pcie_speed == 5.0:
                return 2.0
            else:
                return round(math.log(pcie_speed, 2), 1)
        except Exception:
            # Could not compute, return None
            return None

    @field_validator("pcie_speed_max")
    @classmethod
    def validate_pcie_speed_max(cls, v):
        if v is not None:
            parsed_value = Convert.pcie_speed_to_float(v)
            if parsed_value == 0.0:
                return None
            # Check if the value is 2.5 or 5.0 or a power of 2
            if parsed_value not in [2.5, 5.0] and not (
                parsed_value > 0 and (int(parsed_value) & (int(parsed_value) - 1)) == 0
            ):
                raise ValueError("Invalid pcie_speed_max format")
        return v

    @field_validator("device_id", "vendor_id", "subvendor_device_id", "subvendor_id")
    @classmethod
    def is_hex_value(cls, v):
        if v is not None:
            # Should always be appended with "0x" if not already
            if not v.lower().startswith("0x"):
                v = "0x" + v
            if v.lower() in ["0xnone", "0xbdrv"]:
                v = "0x0000"
            try:
                validators.valid_char_count(char_str=v, max_len=10)
                int(v, 16)
            except ValueError:
                raise ValueError(
                    "must be a valid hexadecimal string of 10 characters or less"
                    '(example: "0x1234")'
                )
        # These values should never be None, default to 0x0000
        elif v is None:
            v = "0x0000"
        return v

    def __hash__(self):
        return hash(
            (
                self.device_id,
                self.vendor_id,
                self.subvendor_device_id,
                self.subvendor_id,
                self.revision,
            )
        )

    def __eq__(self, other):
        if isinstance(other, EthernetControllerModel):
            return hash(self) == hash(other)
        return False
