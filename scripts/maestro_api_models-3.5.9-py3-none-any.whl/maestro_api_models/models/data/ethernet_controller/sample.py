# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Local package imports
from maestro_api_models.models.data.pci_function.sample import PCI_FUNCTION_SAMPLE


ETHERNET_CONTROLLER_SAMPLE = {
    "ethernet_controller_instance_id": 1,
    "ethernet_controller_id": 1,
    "branding_name": "Comstar HPG 2785 (Sample)",
    "cable_type": "Direct Attach Copper",
    "device_id": "0x2785",
    "firmware": "3.04 0x800008c9 1.1767.0",
    "numa_node": 1,
    "nvm_version": "1.1",
    "pcie_speed_max": "8GT/s",
    "pcie_width_current": 4,
    "pcie_width_max": 4,
    "pcie_functions": [PCI_FUNCTION_SAMPLE],
    "revision": "0x01",
    "slot": "J9A5 - PCIE SLOT_E",
    "subvendor_device_id": "0x3132",
    "subvendor_id": "0x3134",
    "vendor_id": "0x2780",
    "codename": "BLACKSTONE",
    "vendor_name": "Intel Corporation",
    "subvendor_name": "Dell Inc",
    "minor_device_name": "X200 (sample)",
    "major_device_name": "Comstar HPG",
    "silicon_family_name": "Niantic",
}

ETHERNET_CONTROLLER_FILTER_MODEL_SAMPLE = {
    "ethernet_controller_id": 1,
    "branding_name": "Comstar HPG 2785 (Sample)",
    "vendor_id": "0x8086",
    "device_id": "0x2785",
    "sub_vendor_id": "0x8086",
    "sub_vendor_device_id": "0x3132",
    "revision": "0x01",
    "codename": "BLACKSTONE",
    "silicon_name": "X200",
    "silicon_family_name": "Niantic",
}

ETHERNET_CONTROLLER_INSTANCE_FILTER_MODEL_SAMPLE = {
    "ethernet_controller_instance_id": 10,
    "system_instance_id": 1,
    "pcie_generation": 3.0,
}
ETHERNET_CONTROLLER_INSTANCE_FILTER_MODEL_SAMPLE.update(
    ETHERNET_CONTROLLER_FILTER_MODEL_SAMPLE
)
