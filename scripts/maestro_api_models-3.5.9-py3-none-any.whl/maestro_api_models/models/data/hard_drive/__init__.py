from .model import HardDriveModel, HardDriveTypeModel
from .sample import HARD_DRIVE_SAMPLE, HARD_DRIVE_TYPE_SAMPLE
