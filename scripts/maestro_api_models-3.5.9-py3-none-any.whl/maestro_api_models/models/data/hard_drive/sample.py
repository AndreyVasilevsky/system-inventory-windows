# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.
from maestro_api_models.models.data.inventory.port.sample import (
    HARD_DRIVE_PORT_FORM_FACTOR,
)

HARD_DRIVE_TYPE_SAMPLE = {
    "hard_drive_type_id": 1,
    "name": "Solid State Drive",
    "abbr": "SSD",
}

HARD_DRIVE_SAMPLE = {
    "hard_drive_id": 1,
    "manufacturer": "Lostech (Sample)",
    "model": "GDL Helm Cache (Sample)",
    "serial_number": "3028",
    "size_gb": 480,
    "hard_drive_type": HARD_DRIVE_TYPE_SAMPLE,
    "port_form_factor": HARD_DRIVE_PORT_FORM_FACTOR,
}
