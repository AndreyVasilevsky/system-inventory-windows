# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import ConfigDict, field_validator

# Local package imports
from maestro_api_models.common import validators
from maestro_api_models.models.data.inventory.extended_field_name.model import (
    ExtendedFieldNameModel,
)
from . import sample


class SystemExtendedFieldModel(ExtendedFieldNameModel):
    system_instance_extended_field_id: int | None = None
    system_instance_id: int | None = None
    reservation_id: int | None = None
    value: str | None = None

    model_config = ConfigDict(
        json_schema_extra={"example": sample.SYSTEM_EXTENDED_FIELD_SAMPLE}
    )

    @field_validator("system_instance_id")
    @classmethod
    def valid_db_id(cls, v):
        if v is not None:
            validators.valid_db_id_signed(v)
        return v

    @field_validator("reservation_id")
    @classmethod
    def valid_db_big_id(cls, v):
        if v is not None:
            validators.valid_db_id_big_signed(v)
        return v

    @field_validator("value")
    @classmethod
    def format_value(cls, v):
        if v is None:
            v = ""
        return v
