# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator


# Local package imports
from maestro_api_models.common.data_validators.network_validators import valid_url
from . import sample


class ProxyConfigurationModel(BaseModel):
    http_proxy_fqdn: str | None = None
    http_proxy_ip_address: str | None = None
    https_proxy_fqdn: str | None = None
    https_proxy_ip_address: str | None = None
    socks_proxy_fqdn: str | None = None
    socks_proxy_ip_address: str | None = None
    rsync_proxy_fqdn: str | None = None
    rsync_proxy_ip_address: str | None = None
    no_proxy: str | None = None

    model_config = ConfigDict(
        json_schema_extra={"example": sample.PROXY_CONFIGURATION_SAMPLE},
        from_attributes=True,
    )

    @field_validator("http_proxy_fqdn")
    @classmethod
    def http_proxy_fqdn_valid_url(cls, v):
        if v is not None:
            if valid_url(v):
                return v
            else:
                return None

    @field_validator("http_proxy_ip_address")
    @classmethod
    def http_proxy_ip_valid_address(cls, v):
        if v is not None:
            if valid_url(v):
                return v
            else:
                return None

    @field_validator("https_proxy_fqdn")
    @classmethod
    def https_proxy_fqdn_valid_url(cls, v):
        if v is not None:
            if valid_url(v):
                return v
            else:
                return None

    @field_validator("https_proxy_ip_address")
    @classmethod
    def https_proxy_ip_valid_address(cls, v):
        if v is not None:
            if valid_url(v):
                return v
            else:
                return None

    @field_validator("rsync_proxy_fqdn")
    @classmethod
    def rsync_proxy_fqdn_valid_url(cls, v):
        if v is not None:
            if valid_url(v):
                return v
            else:
                return None

    @field_validator("rsync_proxy_ip_address")
    @classmethod
    def rsync_proxy_ip_valid_address(cls, v):
        if v is not None:
            if valid_url(v):
                return v
            else:
                return None
