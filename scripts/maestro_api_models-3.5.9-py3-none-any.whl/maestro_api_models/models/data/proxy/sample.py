# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

PROXY_CONFIGURATION_SAMPLE = {
    "http_proxy_fqdn": "http://proxy-dmz.intel.com:912",
    "http_proxy_ip_address": "http://10.7.211.16:912",
    "https_proxy_fqdn": "http://proxy-dmz.intel.com:912",
    "https_proxy_ip_address": "http://10.7.211.16:912",
    "socks_proxy_fqdn": "proxy-dmz.intel.com:1080",
    "socks_proxy_ip_address": "10.7.211.16:1080",
    "rsync_proxy_fqdn": "http://proxy-dmz.intel.com:912",
    "rsync_proxy_ip_address": " http://10.7.211.16:912",
    "no_proxy": "locahost,127.0.0.1/8,.intel.com,172.10.0.0.0/8,134.134.0.0/16",
}
