# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator, Field

# Local package imports
from maestro_api_models.common import validators
from . import sample


class ManufacturerModel(BaseModel):
    manufacturer_id: int = Field(None, alias="id")
    name: str | None = None
    common_name: str | None = None

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={"example": sample.MANUFACTURER_SAMPLE},
    )

    @field_validator("manufacturer_id")
    @classmethod
    def motherboard_id_range(cls, v):
        if v is not None:
            validators.valid_db_id_signed(v)
        return v

    @field_validator("name", "common_name")
    @classmethod
    def char_limit_50(cls, v):
        # VARCHAR(50) in Inventory DB
        if v is not None:
            validators.valid_char_count(char_str=v, max_len=50)
        return v

    def __eq__(self, other):
        if isinstance(other, self.__class__):
            return (
                self.manufacturer_id == other.manufacturer_id
                and self.name == other.name
                and self.common_name == other.common_name
            )
        return False

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash((self.manufacturer_id, self.name))
