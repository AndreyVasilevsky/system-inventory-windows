# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from typing import List
from pydantic import BaseModel, ConfigDict, field_validator

# from Maestro Package Repos
from maestro_api_models.models.data.inventory.pdu.model import PduInstance

# Local imports
from . import sample


class PowerControlPDU(BaseModel):
    pdu_vendor: str
    pdu_instance: PduInstance
    outlets: List[int]

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.PDU_SAMPLE,
        },
    )


@field_validator("pdu_vendor")
@classmethod
def validate_pdu_vendor(cls, v):
    if v is not None:
        return (
            v.upper()
        )  # Return vendor name in upper case, as we'll be using it for matching
    else:
        raise ValueError("Invalid PDU Vendor")


@field_validator("outlets")
@classmethod
def validate_outlets(cls, v):
    if v is not None:
        if isinstance(v, list):
            if not v:  # Check if the list is empty
                raise ValueError("Outlets cannot be empty")
            for i in v:
                if not isinstance(i, int):
                    raise ValueError("Invalid Outlets")
            return v
        else:
            raise ValueError("Invalid Outlets")
