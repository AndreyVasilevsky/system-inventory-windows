# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, field_validator, ConfigDict

# from Maestro Package Repos
from maestro_api_models.common.data_validators.network_validators import (
    valid_hostname,
)
from maestro_api_models.common.data_validators.credential_validators import (
    valid_user_linux,
    valid_pass,
)
from maestro_api_models.common.data_validators.certificate_validators import (
    CertificateValidators,
)


# Local imports
from . import sample


class PowerControlSSH(BaseModel):
    host_address: str | None = None
    ssh_user: str | None = None
    ssh_password: str | None = None
    ssh_priv_key: str | None = None

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.SSH_SAMPLE,
        },
    )

    @field_validator("host_address")
    @classmethod
    def validate_host_address(cls, v):
        if v is not None:
            if valid_hostname(v):
                return v
            else:
                raise ValueError("Invalid Host Address")

    @field_validator("ssh_user")
    @classmethod
    def validate_ssh_user(cls, v):
        if v is not None:
            try:
                valid_user_linux(v, False)
                return v
            except ValueError:
                raise ValueError("Invalid SSH User")

    @field_validator("ssh_password")
    @classmethod
    def validate_ssh_password(cls, v):
        if v is not None:
            try:
                valid_pass(v, False)
                return v
            except ValueError:
                raise ValueError("Invalid SSH Password")

    @field_validator("ssh_priv_key")
    @classmethod
    def validate_ssh_priv_key(cls, v):
        if v is not None:
            if CertificateValidators.string_is_private_key(v):
                return v
            else:
                raise ValueError("Invalid SSH Private Key")
