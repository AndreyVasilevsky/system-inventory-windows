# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict

# Local Package imports
from maestro_api_models.common.decorators import deprecated_class
from maestro_api_models.models.data.system.sample import SYSTEM_SAMPLE
from maestro_api_models.models.data.reservation.model import ReservationModel
from maestro_api_models.models.data.reservation.sample import RES_MODEL_SAMPLE
from maestro_api_models.models.metadata.schema.model import SchemaMetadataModel
from maestro_api_models.models.metadata.schema.sample import SCHEMA_METADATA_SAMPLE


# Request(s)
@deprecated_class("Use the request_response.inventory.reservation module instead.")
class ReservationRequest(BaseModel):
    pools: list[str] | None = None
    reservation: ReservationModel

    # Using `Config` class feature to define examples for ReservationModel instead of Field() as in other classes
    # This allows us to define fields that we don't want to appear in the example as "None", and they will be fully
    # omitted.
    # (When trying to define an example field as "None" in Field(), it will be ignored and use a default like "string")
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "pools": SYSTEM_SAMPLE.get("pools"),
                "reservation": {
                    "reservation_id": RES_MODEL_SAMPLE.get("reservation_id"),
                    "user_idsids": RES_MODEL_SAMPLE.get("user_idsids"),
                    "system_ids": RES_MODEL_SAMPLE.get("system_ids"),
                    "message": None,
                    "success": None,
                    "start_time": RES_MODEL_SAMPLE.get("start_time"),
                    "end_time": RES_MODEL_SAMPLE.get("end_time"),
                    "created_date": None,
                    "last_modified_date": None,
                },
                "schema_metadata": SCHEMA_METADATA_SAMPLE,
            }
        }
    )


# Response(s)
@deprecated_class("Use the request_response.inventory.reservation module instead.")
class ReservationResponse(BaseModel):
    reservations: list[ReservationModel] = []
    schema_metadata: SchemaMetadataModel

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "reservations": [RES_MODEL_SAMPLE],
                "schema_metadata": SCHEMA_METADATA_SAMPLE,
            }
        }
    )
