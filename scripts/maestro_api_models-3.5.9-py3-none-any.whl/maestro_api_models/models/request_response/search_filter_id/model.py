# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator

# Local package imports
from maestro_api_models.common import validators
from maestro_api_models.models.data.system.model import SystemModelBasic
from maestro_api_models.models.data.system.sample import SYSTEM_BASIC_SAMPLE
from maestro_api_models.models.metadata.schema.model import SchemaMetadataModel
from maestro_api_models.models.metadata.schema.sample import SCHEMA_METADATA_SAMPLE


# Request(s)
class SearchSystemIDRequest(BaseModel):
    system: SystemModelBasic
    system_ids: list[int] | None = None
    cpu_ids: list[int] | None = None
    ec_ids: list[int] | None = None
    hdd_ids: list[int] | None = None
    membank_ids: list[int] | None = None
    mobo_ids: list[int] | None = None
    pool_names: list[str] | None = None
    include_decommissioned: bool = False
    include_generic_pool: bool = True
    limit: int | None = None
    offset: int | None = None
    schema_metadata: SchemaMetadataModel

    @field_validator(
        "system_ids", "cpu_ids", "ec_ids", "hdd_ids", "membank_ids", "mobo_ids"
    )
    @classmethod
    def system_ids_filter_positive_numbers(cls, v):
        if v is not None:
            validators.positive_number_list(v)
        return v

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "system": SYSTEM_BASIC_SAMPLE,
                "system_ids": [10, 11, 12],
                "cpu_ids": [4, 5, 6],
                "ec_ids": [7, 8, 9],
                "hdd_ids": [13, 14, 15],
                "membank_ids": [16, 17, 18],
                "mobo_ids": [19, 20, 21],
                "pool_names": SYSTEM_BASIC_SAMPLE.get("pools"),
                "include_decommissioned": False,
                "include_generic_pool": True,
                "limit": 100,
                "offset": 20,
                "schema_metadata": SCHEMA_METADATA_SAMPLE,
            }
        }
    )


# Response(s)
class SearchFilterIDResponse(BaseModel):
    system_results_ids: list[int] = []
    schema_metadata: SchemaMetadataModel

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "system_results_ids": [1, 2, 3],
                "schema_metadata": SCHEMA_METADATA_SAMPLE,
            }
        }
    )
