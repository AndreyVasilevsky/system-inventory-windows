from .list.model import GenericListRequest
