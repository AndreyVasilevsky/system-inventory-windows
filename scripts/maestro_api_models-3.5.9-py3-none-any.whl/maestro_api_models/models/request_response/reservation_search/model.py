# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Standard library imports
from datetime import datetime, timedelta, timezone

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator

# Local package imports
from maestro_api_models.common.decorators import deprecated_class
from maestro_api_models.models.data.reservation.model import ReservationModel
from maestro_api_models.models.data.reservation.sample import RES_MODEL_SAMPLE
from maestro_api_models.models.metadata.schema.model import SchemaMetadataModel
from maestro_api_models.models.metadata.schema.sample import SCHEMA_METADATA_SAMPLE

from maestro_api_models.common.validators import valid_datetime_utc


@deprecated_class("Use the data.date_time_window module instead.")
class DateTimeWindow(BaseModel):
    """Simple class containing set of start and end datetimes, used to define a window of time for backend logic."""

    start: datetime | None = None
    end: datetime | None = None

    @field_validator("start", "end")
    @classmethod
    def datetime_utc_format(cls, v):
        if v is not None:
            valid_datetime_utc(v)
        return v

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "start": datetime.now(timezone.utc),
                "end": datetime.now(timezone.utc) + timedelta(minutes=15),
            }
        }
    )


# Request(s)
@deprecated_class("Use the request_response.inventory.reservation module instead.")
class SearchReservationRequest(BaseModel):
    reservation: ReservationModel | None = None
    end_reservation_window: DateTimeWindow | None = None


# Response(s)
@deprecated_class("Use the request_response.inventory.reservation module instead.")
class SearchReservationResponse(BaseModel):
    reservation_results: list[ReservationModel] = []
    schema_metadata: SchemaMetadataModel

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "reservation_results": [RES_MODEL_SAMPLE],
                "schema_metadata": SCHEMA_METADATA_SAMPLE,
            }
        }
    )
