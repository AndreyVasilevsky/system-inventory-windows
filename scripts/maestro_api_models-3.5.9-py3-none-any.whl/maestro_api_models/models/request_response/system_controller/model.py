# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, field_validator, ConfigDict, Field
from typing import List, Any

# from Maestro Package Repos
from maestro_api_models.common.validators import valid_emails
from maestro_api_models.constants.system_controller_commands import (
    SystemControllerCommands,
)
from maestro_api_models.constants.system_controller_status_codes import (
    SystemControllerStatusCodes,
)
from maestro_api_models.constants.system_controller_callback_codes import (
    SystemControllerCallbackCodes,
)
from maestro_api_models.models.data.system_controller.job_report_data.model import (
    JobReportData,
)
from maestro_api_models.models.metadata.schema.model import SchemaMetadataModel

from . import sample


class SystemControlJobCreateRequestBase(BaseModel):
    payload: Any
    notify_list: List[str] | None = None
    terminate_job_on_failure: bool = Field(
        False, description="Flag to terminate job on failure"
    )

    @field_validator("payload")
    @classmethod
    def check_payload(cls, v):
        if v is None:
            raise ValueError("Payload cannot be None")
        return v

    @field_validator("notify_list")
    @classmethod
    def check_notify_list(cls, v):
        if v is not None:
            if not valid_emails(v):
                raise ValueError("Invalid email address in Notify List")
        return v


class SystemControlJobCreateRequest(SystemControlJobCreateRequestBase):
    job_type: SystemControllerCommands

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_schema_extra={
            "example": sample.SYSTEM_CONTROLLER_REQUEST_EXAMPLE,
        },
    )


class SystemControlJobCreateResponse(BaseModel):
    transaction_id: str
    schema_metadata: SchemaMetadataModel | None = None


class SystemControlJobStatusResponse(BaseModel):
    status: SystemControllerStatusCodes
    schema_metadata: SchemaMetadataModel | None = None


class SystemControlJobLogResponse(BaseModel):
    log: List
    schema_metadata: SchemaMetadataModel | None = None


class SystemControlJobCallback(BaseModel):
    remote_job_status: SystemControllerCallbackCodes
    remote_job_status_message: str

    model_config = model_config = ConfigDict(
        json_encoders={SystemControllerCallbackCodes: lambda v: v.name}
    )


class SystemControlJobReportResponse(BaseModel):
    job_reports: List[JobReportData]
    schema_metadata: SchemaMetadataModel | None = None
