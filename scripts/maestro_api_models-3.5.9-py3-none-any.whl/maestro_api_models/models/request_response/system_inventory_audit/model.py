# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Local Libraries
from maestro_api_models.models.data.system_controller.payload.system_inventory_audit.model import (
    SystemInventoryAuditPayload,
)
from maestro_api_models.models.request_response.system_controller.model import (
    SystemControlJobCreateRequestBase,
    SystemControlJobCreateResponse,
    SystemControlJobStatusResponse,
    SystemControlJobLogResponse,
)


class SystemInventoryAuditCreateRequest(SystemControlJobCreateRequestBase):
    payload: SystemInventoryAuditPayload
    job_id: str
    callback_url: str | None = None


class SystemInventoryAuditCreateResponse(SystemControlJobCreateResponse):
    pass


class SystemInventoryAuditStatusResponse(SystemControlJobStatusResponse):
    pass


class SystemInventoryAuditLogResponse(SystemControlJobLogResponse):
    pass
