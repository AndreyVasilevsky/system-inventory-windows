# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator
from maestro_api_models.common import validators

# Local package imports
from maestro_api_models.common.decorators import deprecated_class
from maestro_api_models.models.metadata.schema.model import SchemaMetadataModel
from maestro_api_models.models.metadata.schema.sample import SCHEMA_METADATA_SAMPLE
from maestro_api_models.models.data.reservation.model import ReservationsBySystemObject


# Request(s)
@deprecated_class("Use the request_response.inventory.reservation module instead.")
class ReservationSystemIDRequest(BaseModel):
    system_ids: list[int] = []
    active_only: bool | None = None

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "system_ids": [10, 11, 12],
                "active_only": True,
                "schema_metadata": SCHEMA_METADATA_SAMPLE,
            }
        }
    )

    @field_validator("system_ids")
    @classmethod
    def system_ids_filter_positive_numbers(cls, v):
        if len(v) > 0:
            validators.positive_number_list(v)
        else:
            raise ValueError("'system_ids' must include at least 1 'system_id' integer")
        return v


# Response(s)
@deprecated_class("Use the request_response.inventory.reservation module instead.")
class ReservationSystemsResponse(BaseModel):
    system_reservations: list[ReservationsBySystemObject]
    schema_metadata: SchemaMetadataModel
