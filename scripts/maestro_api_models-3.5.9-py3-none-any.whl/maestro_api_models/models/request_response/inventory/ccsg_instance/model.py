# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Standard library imports
from typing import List

# Third party library imports
from pydantic import ConfigDict

# Local Package Imports
from maestro_api_models.models.data.ccsg_base.model import CcsgBase
from .sample import (
    CCSG_INSTANCE_REQUEST_SAMPLE,
    CCSG_INSTANCE_RESPONSE_SAMPLE,
    CCSG_INSTANCE_LIST_RESPONSE_SAMPLE,
)
from maestro_api_models.models.request_response.paging_response.model import (
    PagingResponseModel,
)
from maestro_api_models.models.metadata.schema.model import SchemaMetadataModel


class CcsgInstanceRequest(CcsgBase):
    schema_metadata: SchemaMetadataModel | None = None

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "ccsg_instance_request": CCSG_INSTANCE_REQUEST_SAMPLE,
            }
        }
    )


class CcsgInstanceResponse(CcsgBase):
    schema_metadata: SchemaMetadataModel | None = None

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "ccsg_instance_response": CCSG_INSTANCE_RESPONSE_SAMPLE,
            }
        }
    )


class CcsgInstanceListResponse(PagingResponseModel):
    ccsg_instances: List[CcsgBase] | None = None
    schema_metadata: SchemaMetadataModel | None = None

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "ccsg_instance_list_response": CCSG_INSTANCE_LIST_RESPONSE_SAMPLE,
            }
        }
    )
