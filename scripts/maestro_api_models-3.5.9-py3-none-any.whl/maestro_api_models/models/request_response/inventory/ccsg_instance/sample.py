# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

from maestro_api_models.models.request_response.paging_response.sample import (
    PAGING_RESPONSE_SAMPLE,
)

CCSG_INSTANCE_REQUEST_SAMPLE = {
    "ccsg_instance_id": 1,
    "ccsg_url": "https://example.com",
    "display_name": "Example CCSG Instance",
    "schema_metadata": {
        "schema_id": 1,
        "schema_name": "Example Schema",
        "schema_version": "1.0.0",
    },
}

CCSG_INSTANCE_RESPONSE_SAMPLE = {
    "ccsg_instance_id": 1,
    "ccsg_url": "https://example.com",
    "display_name": "Example CCSG Instance",
    "schema_metadata": {
        "schema_id": 1,
        "schema_name": "Example Schema",
        "schema_version": "1.0.0",
    },
}

CCSG_INSTANCE_LIST_RESPONSE_SAMPLE = {
    "ccsg_instances": [
        {
            "ccsg_instance_id": 1,
            "ccsg_url": "https://example.com",
            "display_name": "Example CCSG Instance",
        },
        {
            "ccsg_instance_id": 2,
            "ccsg_url": "https://example2.com",
            "display_name": "Example CCSG Instance 2",
        },
    ],
    "schema_metadata": {
        "schema_id": 1,
        "schema_name": "Example Schema",
        "schema_version": "1.0.0",
    },
    **PAGING_RESPONSE_SAMPLE,
}
