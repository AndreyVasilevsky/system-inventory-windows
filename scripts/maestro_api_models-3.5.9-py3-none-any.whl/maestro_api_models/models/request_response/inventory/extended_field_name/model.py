# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Standard library imports
from typing import List

# Third party library imports
from pydantic import BaseModel, ConfigDict

# Local Package Imports
from maestro_api_models.models.data.inventory.extended_field_name.model import (
    ExtendedFieldNameModel,
)
from maestro_api_models.models.data.inventory.extended_field_name.sample import (
    EXTENDED_FIELD_NAME_SAMPLE,
)
from maestro_api_models.models.metadata.schema.model import SchemaMetadataModel
from maestro_api_models.models.metadata.schema.sample import SCHEMA_METADATA_SAMPLE


class ExtendedFieldNameRequest(BaseModel):
    extended_field_name: ExtendedFieldNameModel
    schema_metadata: SchemaMetadataModel | None = None

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "extended_field_name": EXTENDED_FIELD_NAME_SAMPLE,
            }
        }
    )


class ExtendedFieldNameResponse(BaseModel):
    extended_field_names: List[ExtendedFieldNameModel]
    schema_metadata: SchemaMetadataModel

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "system_extended_fields": [
                    EXTENDED_FIELD_NAME_SAMPLE,
                    EXTENDED_FIELD_NAME_SAMPLE,
                ],
                "schema_metadata": SCHEMA_METADATA_SAMPLE,
            }
        }
    )
