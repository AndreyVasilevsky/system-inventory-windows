# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials, and your use of them is governed
# by the express license under which they were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit this software or the related documents
# without Intel's prior written permission.
#
# This software and the related documents are provided as is, with no express or implied warranties,
# other than those that are expressly stated in the License.

# Standard Package Imports
from typing import List

# Third Party package Imports
from pydantic import BaseModel, ConfigDict

# Local Package Imports
from maestro_api_models.models.data.lab.model import LabModel
from maestro_api_models.models.metadata.schema.model import SchemaMetadataModel
from maestro_api_models.models.request_response.paging_response.model import (
    PagingResponseModel,
)

from . import sample


class LabResponseBase(BaseModel):
    lab: LabModel | None = None
    schema_metadata: SchemaMetadataModel | None = None

    model_config = ConfigDict(
        validate_assignment=True,
        json_schema_extra={"example": sample.LAB_RESPONSE_SAMPLE},
    )


class LabListResponseBase(PagingResponseModel):
    labs: List[LabModel] | None = None
    schema_metadata: SchemaMetadataModel | None = None

    model_config = ConfigDict(
        validate_assignment=True,
        json_schema_extra={"example": sample.LAB_LIST_RESPONSE_SAMPLE},
    )


class GetLabResponse(LabResponseBase):
    pass


class GetLabListResponse(LabListResponseBase):
    pass


class CreateLabResponse(LabResponseBase):
    pass


class CreateLabRequest(LabModel):
    pass


class UpdateLabResponse(LabResponseBase):
    pass


class UpdateLabRequest(LabModel):
    pass
