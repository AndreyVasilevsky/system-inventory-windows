# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

from typing import List

# Third party library imports
from pydantic import BaseModel, ConfigDict

from maestro_api_models.models.metadata.schema.model import SchemaMetadataModel
from maestro_api_models.models.metadata.schema.sample import SCHEMA_METADATA_SAMPLE
from maestro_api_models.models.data.system_extended_field.model import (
    SystemExtendedFieldModel,
)
from maestro_api_models.models.data.system_extended_field.sample import (
    SYSTEM_EXTENDED_FIELD_SAMPLE,
    SYSTEM_EXTENDED_FIELD_SAMPLE_RES,
)


class SystemExtendedFieldRequest(BaseModel):
    system_extended_field: SystemExtendedFieldModel
    schema_metadata: SchemaMetadataModel | None = None

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "system_extended_field": SYSTEM_EXTENDED_FIELD_SAMPLE_RES,
                "schema_metadata": SCHEMA_METADATA_SAMPLE,
            }
        }
    )


class SystemExtendedFieldResponse(BaseModel):
    system_extended_fields: List[SystemExtendedFieldModel]
    schema_metadata: SchemaMetadataModel

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "system_extended_fields": [
                    SYSTEM_EXTENDED_FIELD_SAMPLE,
                    SYSTEM_EXTENDED_FIELD_SAMPLE_RES,
                ],
                "schema_metadata": SCHEMA_METADATA_SAMPLE,
            }
        }
    )
