from maestro_api_models.models.data.reservation.model import ReservationTypes
from maestro_api_models.models.data.reservation.sample import RES_MODEL_SAMPLE
from maestro_api_models.models.metadata.schema.sample import SCHEMA_METADATA_SAMPLE

__reservation_model_base_ignore_keys = ["message", "success"]
__reservation_model_create_ignore_keys = [
    "created_date",
    "last_modified_date",
    "message",
    "success",
]
reservation_types_values = [
    value
    for key, value in vars(ReservationTypes).items()
    if not key.startswith("__") and not callable(value)
]

RESERVATION_MODEL_REQUEST_UPDATE_SAMPLE = {
    key: value
    for key, value in RES_MODEL_SAMPLE.items()
    if key not in __reservation_model_create_ignore_keys
}
RESERVATION_MODEL_REQUEST_CREATE_SAMPLE = {
    key: value
    for key, value in RESERVATION_MODEL_REQUEST_UPDATE_SAMPLE.items()
    if key != "reservation_id"
}
RESERVATION_MODEL_REQUEST_BASE_SAMPLE = {
    key: value
    for key, value in RESERVATION_MODEL_REQUEST_CREATE_SAMPLE.items()
    if key not in __reservation_model_base_ignore_keys
}

RESERVATION_REQUEST_UPDATE_SAMPLE = {
    "reservation": RESERVATION_MODEL_REQUEST_UPDATE_SAMPLE
}

RESERVATION_REQUEST_CREATE_SAMPLE = {
    "reservation": RESERVATION_MODEL_REQUEST_CREATE_SAMPLE
}

SEARCH_RESERVATION_REQUEST_SAMPLE = {
    "reservation": RES_MODEL_SAMPLE,
    "end_reservation_window": {
        "start": RES_MODEL_SAMPLE.get("start_time"),
        "end": RES_MODEL_SAMPLE.get("end_time"),
    },
}

RESERVATION_LIST_BASE_SAMPLE = {"reservations": [RES_MODEL_SAMPLE]}

RESERVATION_TYPE_RESPONSE_SAMPLE = {
    "reservation_types": reservation_types_values,
    "schema_metadata": SCHEMA_METADATA_SAMPLE,
}

RESERVATION_BASE_RESPONSE_SAMPLE = {
    "reservations": [RES_MODEL_SAMPLE],
    "schema_metadata": SCHEMA_METADATA_SAMPLE,
}

RESERVATION_SYSTEM_ID_REQUEST_SAMPLE = {"system_ids": [10, 11], "active_only": True}

RESERVATION_SEARCH_REQUEST_SAMPLE = {
    "reservation": RES_MODEL_SAMPLE,
    "end_reservation_window": {
        "start": RES_MODEL_SAMPLE.get("start_time"),
        "end": RES_MODEL_SAMPLE.get("end_time"),
    },
}
