# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

from typing import List

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator

# Local Package imports
from maestro_api_models.models.data.date_time_window import DateTimeWindow
from maestro_api_models.models.data.reservation import ReservationModel
from maestro_api_models.models.request_response.inventory.reservation import sample
from maestro_api_models.models.metadata.schema.model import SchemaMetadataModel

from maestro_api_models.common import validators


# region Requests
class ReservationBaseRequest(BaseModel):
    reservation: ReservationModel

    # Using `Config` class feature to define examples for ReservationModel instead of Field() as in other classes
    # This allows us to define fields that we don't want to appear in the example as "None", and they will be fully
    # omitted.
    # (When trying to define an example field as "None" in Field(), it will be ignored and use a default like "string")
    model_config = ConfigDict(
        json_schema_extra={"example": sample.RESERVATION_MODEL_REQUEST_BASE_SAMPLE}
    )


class ReservationCreateRequest(ReservationBaseRequest):
    model_config = ConfigDict(
        json_schema_extra={"example": sample.RESERVATION_MODEL_REQUEST_CREATE_SAMPLE},
        validate_assignment=True,
        use_enum_values=True,
    )


class ReservationUpdateRequest(ReservationBaseRequest):
    model_config = ConfigDict(
        json_schema_extra={"example": sample.RESERVATION_MODEL_REQUEST_UPDATE_SAMPLE},
        validate_assignment=True,
        use_enum_values=True,
    )


class ReservationSearchRequest(BaseModel):
    reservation: ReservationModel | None = None
    end_reservation_window: DateTimeWindow | None = None

    model_config = ConfigDict(
        json_schema_extra={
            "example": sample.RESERVATION_SEARCH_REQUEST_SAMPLE,
        },
        validate_assignment=True,
    )


class ReservationSystemIDRequest(BaseModel):
    system_ids: List[int] = []
    active_only: bool | None = None

    model_config = ConfigDict(
        json_schema_extra={"example": sample.RESERVATION_SYSTEM_ID_REQUEST_SAMPLE},
        validate_assignment=True,
    )

    @field_validator("system_ids")
    @classmethod
    def system_ids_filter_positive_numbers(cls, v):
        if len(v) > 0:
            validators.positive_number_list(v)
        else:
            raise ValueError("'system_ids' must include at least 1 'system_id' integer")
        return v


# region Responses
class ReservationBaseResponse(BaseModel):
    reservations: List[ReservationModel] = []
    schema_metadata: SchemaMetadataModel

    model_config = ConfigDict(
        json_schema_extra={"example": sample.RESERVATION_BASE_RESPONSE_SAMPLE}
    )


class ReservationTypeResponse(BaseModel):
    reservation_types: List[str]
    schema_metadata: SchemaMetadataModel

    model_config = ConfigDict(
        json_schema_extra={"example": sample.RESERVATION_TYPE_RESPONSE_SAMPLE}
    )


class ReservationCreateResponse(ReservationBaseResponse):
    pass


class ReservationUpdateResponse(ReservationBaseResponse):
    pass


class ReservationEndResponse(ReservationBaseResponse):
    pass


class ReservationStatusResponse(ReservationBaseResponse):
    pass


class ReservationSearchResponse(ReservationBaseResponse):
    pass
