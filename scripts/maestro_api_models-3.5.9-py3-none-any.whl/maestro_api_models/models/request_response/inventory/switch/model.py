# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel
from typing import List

# from Maestro Package Repos
from maestro_api_models.models.metadata.schema.model import SchemaMetadataModel
from maestro_api_models.models.data.inventory.switch.model import (
    Switch,
    SwitchModelFullDetail,
    SwitchInstance,
    SwitchInstanceFullDetails,
    SwitchPortInstance,
    SwitchPortInstanceFullDetails,
    SwitchPortMap,
)


# == Switch Model == #


class SwitchModelCreateRequest(BaseModel):
    switch_model: Switch


class SwitchModelGetAllResponse(BaseModel):
    switch_models: List[SwitchModelFullDetail] | None = []
    schema_metadata: SchemaMetadataModel | None = None


class SwitchModelGetOneResponse(BaseModel):
    switch_model: SwitchModelFullDetail | None = None
    schema_metadata: SchemaMetadataModel | None = None


class SwitchCreateResponse(BaseModel):
    switch_id: int
    schema_metadata: SchemaMetadataModel | None = None


# == Switch Instance == #


class SwitchInstanceCreateRequest(BaseModel):
    switch_data: SwitchInstance


class SwitchInstanceGetAllResponse(BaseModel):
    switches: List[SwitchInstanceFullDetails] | None = []
    schema_metadata: SchemaMetadataModel | None = None


class SwitchInstanceGetOneResponse(BaseModel):
    switch_instance: SwitchInstanceFullDetails | None = None
    schema_metadata: SchemaMetadataModel | None = None


class SwitchInstanceCreateResponse(BaseModel):
    switch_instance_id: int
    schema_metadata: SchemaMetadataModel | None = None


# == Switch Port Instance == #


class SwitchPortInstanceCreateRequest(BaseModel):
    port: SwitchPortInstance


class SwitchPortInstanceCreateMultipleRequest(BaseModel):
    ports: List[SwitchPortInstance]


class SwitchPortInstanceCreateResponse(BaseModel):
    switch_port_instance_id: int
    schema_metadata: SchemaMetadataModel | None = None


class SwitchPortInstanceCreateMultipleResponse(BaseModel):
    switch_port_instance_ids: List[int]
    schema_metadata: SchemaMetadataModel | None = None


class SwitchPortInstanceResponse(BaseModel):
    switch_port: SwitchPortInstanceFullDetails | None = None
    schema_metadata: SchemaMetadataModel | None = None


class PhysicalSwitchPortInstanceDeleteRequest(BaseModel):
    switch_instance_id: int
    port_maps: List[int]


class LogicalSwitchPortInstanceDeleteRequest(BaseModel):
    switch_instance_id: int
    port_maps: List[str]


# == Switch Port Map == #


class SwitchPortMapResponse(BaseModel):
    port_mapping: SwitchPortMap | None = None
    schema_metadata: SchemaMetadataModel | None = None


# == SwitchInstanceCompleteModelResponse == #
class SwitchInstanceCompleteModelResponse(BaseModel):
    switch_instance_full: SwitchInstanceFullDetails
    switch_ports_full: List[SwitchPortInstanceFullDetails]
    schema_metadata: SchemaMetadataModel | None = None
