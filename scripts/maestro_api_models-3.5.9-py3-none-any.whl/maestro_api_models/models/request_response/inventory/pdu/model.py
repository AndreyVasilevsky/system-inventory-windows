# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel
from typing import List

# from Maestro Package Repos
from maestro_api_models.models.metadata.schema.model import SchemaMetadataModel
from maestro_api_models.models.data.inventory.pdu.model import (
    Pdu,
    PduModelFullDetail,
    PduInstance,
    PduInstanceFullDetail,
    SystemInstancePduOutletMap,
    SystemOutletMap,
)


class PduModelCreateRequest(BaseModel):
    pdu_model: Pdu


class PduModelGetAllResponse(BaseModel):
    pdu_models: List[PduModelFullDetail] | None = []
    schema_metadata: SchemaMetadataModel | None = None


class PduModelGetOneResponse(BaseModel):
    pdu_model: PduModelFullDetail | None = None
    schema_metadata: SchemaMetadataModel | None = None


class PduInstanceCreateRequest(BaseModel):
    pdu_data: PduInstance


class PduInstanceGetAllResponse(BaseModel):
    pdus: List[PduInstanceFullDetail] | None = []
    schema_metadata: SchemaMetadataModel | None = None


class PduInstanceGetOneResponse(BaseModel):
    pdu_instance: PduInstanceFullDetail | None = None
    schema_metadata: SchemaMetadataModel | None = None


class SystemInstancePduOutletMapRequest(BaseModel):
    outlet_map: List[SystemInstancePduOutletMap]


class PduCreateResponse(BaseModel):
    pdu_id: int
    schema_metadata: SchemaMetadataModel | None = None


class PduInstanceCreateResponse(BaseModel):
    pdu_instance_id: int
    schema_metadata: SchemaMetadataModel | None = None


class SystemOutletMapResponse(BaseModel):
    outlet_mapping: SystemOutletMap | None = None
    schema_metadata: SchemaMetadataModel | None = None
