from maestro_api_models.models.data.osd import OsdOs
from maestro_api_models.models.request_response.osd.paging_response.model import (
    PagingOsdResponseModel,
)


class GetOsHostIsoListResponse(PagingOsdResponseModel[OsdOs]):
    pass
