from .model import HealthResponse, ProcessHealthResponse
