# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict
from typing import List

# Local package imports
from maestro_api_models.models.metadata.schema.model import SchemaMetadataModel
from maestro_api_models.models.metadata.schema.sample import SCHEMA_METADATA_SAMPLE
from maestro_api_models.models.data.osc.customization.model import (
    CustomizationModel,
    CustomizationModelFull,
)
from maestro_api_models.models.data.osc.customization.sample import (
    CUSTOMIZATION_MODEL_SAMPLE,
)


class CustomizationResponse(BaseModel):
    customization: list[CustomizationModelFull]
    schema_metadata: SchemaMetadataModel

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "customization": CUSTOMIZATION_MODEL_SAMPLE,
                "schema_metadata": SCHEMA_METADATA_SAMPLE,
            }
        }
    )


class CustomizationRequest(BaseModel):
    customization: CustomizationModel
    schema_metadata: SchemaMetadataModel | None = None

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "customization": CUSTOMIZATION_MODEL_SAMPLE,
                "schema_metadata": SCHEMA_METADATA_SAMPLE,
            }
        }
    )


class CustomizationModifyRoleRequest(BaseModel):
    add_roles: List[int] = []
    del_roles: List[int] = []
    schema_metadata: SchemaMetadataModel | None = None

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "add_roles": [2, 4, 5],
                "del_roles": [1, 3],
                "schema_metadata": SCHEMA_METADATA_SAMPLE,
            }
        }
    )


class CustomizationModifyAccessRequest(BaseModel):
    add_idsid: List[str] = []
    add_group: List[str] = []
    del_idsid: List[str] = []
    del_group: List[str] = []
    schema_metadata: SchemaMetadataModel | None = None

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "add_idsid": ["employe1", "employe2"],
                "add_group": ["Group A"],
                "del_idsid": ["employe3"],
                "del_group": ["Azure enabled PDL B", "Azure Group C"],
                "schema_metadata": SCHEMA_METADATA_SAMPLE,
            }
        }
    )
