# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator

# Local package imports
from maestro_api_models.common.validators import valid_emails
from maestro_api_models.models.metadata.schema.model import SchemaMetadataModel
from maestro_api_models.models.metadata.schema.sample import SCHEMA_METADATA_SAMPLE


# Enum-Style Classes
class NotifierStatusTypes:
    """Defined and accepted values for notification status."""

    SUCCESS = "Your message was sent. This is NOT a guarantee it will be delivered."
    FAILURE = "Your message failed to send."


# Request(s)
class NotificationEmailRequest(BaseModel):
    to: list[str]
    subject: str
    body: str
    cc: list[str] | None = None
    bcc: list[str] | None = None
    schema_metadata: SchemaMetadataModel

    @field_validator("to", "cc", "bcc")
    @classmethod
    def email_addresses_valid(cls, v):
        if v is not None:
            valid_emails(v)
        return v

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "to": ["user@example.com"],
                "subject": "Example subject",
                "body": "Example email content.",
                "cc": ["boss@example.com", "bosses.boss@example.com"],
                "bcc": ["co.worker@example.com"],
                "schema_metadata": SCHEMA_METADATA_SAMPLE,
            }
        }
    )


# Response(s)
class NotificationResponse(BaseModel):
    details: str
    schema_metadata: SchemaMetadataModel

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "details": NotifierStatusTypes.SUCCESS,
                "schema_metadata": SCHEMA_METADATA_SAMPLE,
            }
        }
    )
