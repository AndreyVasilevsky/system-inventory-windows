# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel


# Data Models
from maestro_api_models.models.data.proxy.model import ProxyConfigurationModel
from maestro_api_models.models.data.bastion.model import BastionServerAccessModel
from maestro_api_models.models.data.network.model import LabNetworkModel
from maestro_api_models.models.data.awx_controller.model import AwxControllerModel
from maestro_api_models.models.data.ccsg_address.model import CcsgAddressModel
from maestro_api_models.models.data.network_lookup.osd_storage_satellite.model import (
    OsdStorageSatelliteModel,
)
from maestro_api_models.models.data.network_lookup.dns.model import DnsModel
from maestro_api_models.models.data.network_lookup.zabbix_proxy.model import (
    ZabbixProxyModel,
)

from maestro_api_models.models.metadata.schema.model import SchemaMetadataModel


class NetworkLookupResponse(BaseModel):
    network: LabNetworkModel
    bastion: BastionServerAccessModel | None = None
    proxy: ProxyConfigurationModel
    awx_controller: AwxControllerModel | None = None
    ccsg: CcsgAddressModel | None = None
    osd_storage_satellite: OsdStorageSatelliteModel | None = None
    dns: DnsModel | None = None
    zabbix: ZabbixProxyModel | None = None
    schema_metadata: SchemaMetadataModel


class NetworkLookupBastionResponse(BaseModel):
    bastion: BastionServerAccessModel
    schema_metadata: SchemaMetadataModel


class NetworkLookupProxyResponse(BaseModel):
    proxy: ProxyConfigurationModel
    schema_metadata: SchemaMetadataModel


class NetworkLookupAwxResponse(BaseModel):
    awx_controller: AwxControllerModel
    schema_metadata: SchemaMetadataModel


class NetworkLookupCcsgResponse(BaseModel):
    ccsg: CcsgAddressModel
    schema_metadata: SchemaMetadataModel


class NetworkLookupOsdResponse(BaseModel):
    osd_storage_satellite: OsdStorageSatelliteModel
    schema_metadata: SchemaMetadataModel


class NetworkLookupDnsResponse(BaseModel):
    dns: DnsModel
    schema_metadata: SchemaMetadataModel


class NetworkLookupZabbixProxyResponse(BaseModel):
    zabbix: ZabbixProxyModel
    schema_metadata: SchemaMetadataModel
