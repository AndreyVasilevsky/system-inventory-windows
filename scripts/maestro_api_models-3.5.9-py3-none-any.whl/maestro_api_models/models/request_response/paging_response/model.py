# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third Party package imports
from pydantic import BaseModel, ConfigDict, field_validator

from maestro_api_models.common import validators
from . import sample


class PagingResponseModel(BaseModel):
    num_results: int | None = None
    page: int | None = None
    total_pages: int | None = None
    next_page: int | None = None
    previous_page: int | None = None

    model_config = ConfigDict(
        json_schema_extra={"example": sample.PAGING_RESPONSE_SAMPLE},
    )

    @field_validator("num_results", "page", "total_pages", "next_page", "previous_page")
    @classmethod
    def valid_paging_values(cls, v):
        if v is not None:
            validators.positive_number(v)
        return v
