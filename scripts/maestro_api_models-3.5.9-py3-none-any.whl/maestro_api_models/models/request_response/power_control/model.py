# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, field_validator
from typing import List

# from Maestro Package Repos
from maestro_api_models.constants.power_commands import PowerCommands
from maestro_api_models.models.metadata.schema.model import SchemaMetadataModel
from maestro_api_models.common.data_validators.network_validators import (
    valid_mac_address,
)
from maestro_api_models.models.data.power_control.ccsg.model import PowerControlCCSG
from maestro_api_models.models.data.power_control.bastion.model import (
    PowerControlBastion,
)
from maestro_api_models.models.data.power_control.ssh.model import PowerControlSSH
from maestro_api_models.models.data.power_control.bmc.model import PowerControlBMC
from maestro_api_models.models.data.power_control.pdu.model import PowerControlPDU


class PowerControlCreateRequest(BaseModel):
    system_mac_address: str
    power_action: PowerCommands
    allow_hard_power_cycle: bool | None = True
    power_button_off_time: int | None = 60
    power_button_on_time: int | None = 60
    ssh: PowerControlSSH | None = None
    bastion: PowerControlBastion | None = None
    ccsg: PowerControlCCSG | None = None
    bmc: PowerControlBMC | None = None
    pdu: List[PowerControlPDU] | None = None

    @field_validator("system_mac_address")
    @classmethod
    def validate_mac_address(cls, value):
        if not valid_mac_address(value):
            raise ValueError(
                "A valid mac address is required for the system_mac_address field."
            )
        return value


class PowerControlCreateResponse(BaseModel):
    transaction_id: str
    schema_metadata: SchemaMetadataModel | None = None


class PowerControlStatusResponse(BaseModel):
    transaction_id: str
    status: str
    log: List
    schema_metadata: SchemaMetadataModel | None = None


class PowerOptionsRequest(BaseModel):
    system_mac_address: str | None = None
    allow_hard_power_cycle: bool | None = True
    ssh: PowerControlSSH | None = None
    ccsg: PowerControlCCSG | None = None
    bmc: PowerControlBMC | None = None
    pdu: List[PowerControlPDU] | None = None

    @field_validator("system_mac_address")
    @classmethod
    def validate_mac_address(cls, value):
        if not valid_mac_address(value):
            raise ValueError(
                "A valid mac address is required for the system_mac_address field."
            )
        return value


class PowerOptionsResponse(BaseModel):
    power_options: List[PowerCommands]
    schema_metadata: SchemaMetadataModel | None = None
