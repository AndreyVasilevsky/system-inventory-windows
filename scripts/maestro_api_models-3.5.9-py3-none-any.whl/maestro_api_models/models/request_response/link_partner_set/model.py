# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Third party library imports
from pydantic import BaseModel, ConfigDict, field_validator

# Local package imports
from maestro_api_models.common.validators import valid_mac_address

from maestro_api_models.models.metadata.schema.model import SchemaMetadataModel
from maestro_api_models.models.metadata.schema.sample import SCHEMA_METADATA_SAMPLE


class LinkPartnerCollectionStatus(BaseModel):
    link_partner_set: list[str] = []
    status: str | None = None


# Request(s)
class LinkPartnerSetRequest(BaseModel):
    link_partner_sets: list[list[str]] = []
    schema_metadata: SchemaMetadataModel

    @field_validator("link_partner_sets")
    @classmethod
    def mgt_mac_address_format(cls, v):
        for index, link_partner_set in enumerate(v):
            if len(link_partner_set) < 2:
                raise ValueError(
                    f"link partner set at index {index} contains less than the minimum number of management mac "
                    f"addresses (2) to form a set of link partners"
                )
            else:
                for mac in link_partner_set:
                    try:
                        valid_mac_address(mac)
                    except ValueError as ve:
                        raise ValueError(
                            f"link partner set at index {index} invalid, {ve}"
                        )
        return v

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "link_partner_sets": [
                    ["00:00:00:00:00:00", "11:11:11:11:11:11"],
                    ["0F:F0:0F:F0:0F:F0", "10:01:10:01:10:01", "9A:A9:9A:A9:9A:A9"],
                ],
                "schema_metadata": SCHEMA_METADATA_SAMPLE,
            }
        }
    )


# Response(s)
class LinkPartnerSetResponse(BaseModel):
    failed_pairings: list[LinkPartnerCollectionStatus] = []
    message: str | None = None
    schema_metadata: SchemaMetadataModel

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "failed_pairings": [],
                "message": "all link partner sets successfully added",
                "schema_metadata": SCHEMA_METADATA_SAMPLE,
            }
        }
    )
