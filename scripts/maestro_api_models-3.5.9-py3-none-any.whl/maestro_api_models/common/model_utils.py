# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.
# Standard Libraries
from urllib.parse import urlparse
import ipaddress


def get_model_fields(module: object, class_name: str) -> list[str]:
    """
    Get the fields of a model class.

    Args:
        module (object): The module containing the model class.
        class_name (str): The name of the model class.

    Returns:
        list[str]: The list of field names.

    """
    return [
        v
        for k, v in getattr(module, class_name).__dict__.items()
        if not str(hex(id(v))) in str(v)
        and not (k.startswith("__") and k.endswith("__"))
    ]


def ensure_https(url):
    """
    Ensure that the URL starts with "https://".

    Args:
        url (str): The URL to ensure.

    Returns:
        str: The URL with "https://" prefix.

    """
    # Check if the URL starts with "http://" or "https://"
    if url.startswith("http://"):
        # Remove "http://" and add "https://"
        return "https://" + url[len("http://") :]
    elif url.startswith("https://"):
        # If it already starts with "https://", return as is
        return url
    else:
        return f"https://{url}"


def extract_fqdn(url):
    """
    Extract the fully qualified domain name (FQDN) or IP address from a given URL.

    Args:
        url (str): The URL from which to extract the FQDN or IP address.

    Returns:
        str: The extracted FQDN or IP address.

    Raises:
        ValueError: If the URL is invalid or cannot be parsed.
    """
    # This is done to ensure that the URL fed in starts with a protocol
    # Otherwise, urlparse will not parse it correctly
    url = ensure_https(url)
    # Parse the URL
    parsed_url = urlparse(url)

    # Extract the netloc part
    netloc = parsed_url.netloc.split(":")[0]  # Remove port number if present

    # Check if the netloc is an IP address
    try:
        ipaddress.ip_address(netloc)
        return netloc  # Return IP address if it's valid
    except ValueError:
        # Return domain name if it's not an IP address
        return netloc
