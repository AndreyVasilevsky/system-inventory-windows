# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.
import warnings


def deprecated_class(custom_message=None):
    """
    Mark class as deprecated with an optional custom message.

    Args:
        custom_message (str): Custom deprecation message to show.
    """

    def decorator(cls):
        class DeprecatedClass(cls):
            def __init__(self, *args, **kwargs):
                message = (
                    f"{cls.__name__} is deprecated and may be removed in future versions.\n\n{custom_message}"
                    if custom_message
                    else f"{cls.__name__} is deprecated and may be removed in future versions."
                )
                warnings.warn(
                    message,
                    category=DeprecationWarning,
                    stacklevel=2,
                )
                super().__init__(*args, **kwargs)

        DeprecatedClass.__name__ = cls.__name__
        DeprecatedClass.__doc__ = cls.__doc__
        DeprecatedClass.__module__ = cls.__module__
        return DeprecatedClass

    return decorator
