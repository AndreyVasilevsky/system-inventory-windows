# TEMPLATE
class Convert:
    @staticmethod
    def pcie_speed_to_float(value: str) -> float:
        try:
            # Extract the numeric part of the string
            numeric_value = "".join(filter(lambda x: x.isdigit() or x == ".", value))
            return round(float(numeric_value), 1)
        except ValueError:
            raise ValueError(f"Invalid input for conversion: {value}")
