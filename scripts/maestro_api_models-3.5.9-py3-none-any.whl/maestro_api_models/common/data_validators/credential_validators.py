# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

from maestro_api_models.common.data_validators.network_validators import valid_email

from re import match, search


def valid_user_linux(linux_user: str = None, is_domain_member: bool = True) -> None:
    # Validate that an incoming linux user is meets minimum security requirements.
    if linux_user is None:
        raise ValueError("Linux User cannot be blank")

    if not bool(match(r"^[A-Za-z0-9_.\-@]*$", linux_user)):
        raise ValueError("Only a-z,A-Z,0-9,_,-,@,. allowed in Linux User Accounts")

    if len(linux_user) < 3:
        raise ValueError("Linux Users must be at least 3 characters long")

    if is_domain_member:
        if not valid_email(linux_user):
            raise ValueError("Linux user not in email-style format 'user'@'domain.com'")

    return None


def valid_pass(password=None, strong_pasword_required: bool = True) -> None:
    # Validate that supplied password meets minimums.
    if password is None:
        raise ValueError("Password cannot be blank")

    if strong_pasword_required:
        if len(password) < 6:
            raise ValueError("Password is too short, minimum password length is 6")

        if not search(r"[a-z]", password):
            raise ValueError("Password must contain lowercase letters")

        if not search(r"[A-Z]", password):
            raise ValueError("Password must contain Uppercase letters")

        if not search("[0-9]", password):
            raise ValueError("Password must contain numbers")

        if not search(r"[_@$%&*\!\-=+\(\)]", password):
            raise ValueError("Password must contain special characters")

    return None
