# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Standard library imports
from ipaddress import ip_address, IPv4Address, IPv6Address
from re import match


# Third party library imports
from validators import (
    url,
    domain,
    mac_address,
    ip_address as ipaddresstools,
    hostname,
    ValidationError,
)


def valid_domain(fqdn_str: str) -> bool:
    """Validate the supplied Fully Qualified Domain Name (FQDN).

    This function checks if the provided string is a valid FQDN by using the `domain`
    function from the `validators` library. If the string is a valid FQDN, the function returns True.
    If the string is not a valid FQDN or if a ValidationError is raised, the function returns False.

    Args:
        fqdn_str (str): The string to validate as a FQDN.

    Returns:
        bool: True if the string is a valid FQDN, False otherwise.

    Examples:
        domain.com == True
        TheCakeIsaLie == False
        192.168.1.1 == False
    """
    try:
        return domain(fqdn_str)
    except ValidationError:
        return False


def valid_ipv4_to_int_value(checkvalue: int) -> bool:
    """Verify that the supplied value is a valid IPv4 address cast to an integer value."""
    if not isinstance(checkvalue, int):
        return False

    if checkvalue >= 0 and checkvalue <= 4294967295:
        return True
    else:
        return False


def valid_cidr(cidr_str: str) -> bool:
    """Ensure that the supplied value fits IPv4 CIDR formatting."""
    try:
        return ipaddresstools.ipv4(cidr_str, cidr=True, strict=True)
    except ValidationError:
        return False


def valid_url(uri_str: str, skip_ip_addresses=False) -> bool:
    """Validate that the supplied URL is a valid Uri.

    Inputs:
        uri_str: URL String
        skip_ip_address: Default false, if true, will return false if
                         a the supplied value is an IPv4 Address.

    Responses:
        skip_ipv4==false
            True if valid URL
            False if not valid URL
        skip_ipv4==true
            True if URL is valid and uses an FQDN
            False if the URL is not valid or uses an IPv4 address
    """
    try:
        return url(uri_str, skip_ipv4_addr=skip_ip_addresses)
    except ValidationError:
        return False


def valid_email(email: str) -> bool:
    """Validate that the supplied value is a valid email."""
    if not match(r".+@.+\..+", email):
        return False

    return True


def valid_emails(emails: list[str]) -> bool:
    """Perform `Valid Email Check` for all values of a list."""
    for email in emails:
        if not valid_email(email):
            return False

    return True


def valid_ip_address(ip: str) -> bool:
    """Verify if the supplied value is a valid IPv4 or IPv6 Address."""
    try:
        invalid = False if type(ip_address(ip)) in [IPv4Address, IPv6Address] else True
    except ValueError:
        invalid = True
    if invalid:
        return False
    return True


def valid_mac_address(mac: str) -> bool:
    """Validate that the supplied value is a valid MAC address."""
    try:
        return bool(mac_address(mac))
    except ValidationError:
        return False


def valid_hostname(supplied_hostname: str) -> bool:
    """Validate that the supplied value is a valid hostname.

    Examples:
        domain.com == True
        _domain.com == True
        192.168.1.1 == True
        RandomExamplehost == True
    """
    try:
        return hostname(supplied_hostname)
    except ValidationError:
        return False
