# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

from OpenSSL.crypto import (
    load_certificate,
    load_privatekey,
    dump_publickey,
    FILETYPE_PEM,
)


from re import match, search


class CertificateValidators:
    def __init__(self) -> None:
        """Initialize the Certificate Validators Class."""
        pass

    @staticmethod
    def validate_pair(cert_data, key_data):
        # Load the certificate
        cert = load_certificate(FILETYPE_PEM, cert_data)
        key = load_privatekey(FILETYPE_PEM, key_data)
        cert_pub = dump_publickey(FILETYPE_PEM, cert.get_pubkey())
        key_pub = dump_publickey(FILETYPE_PEM, key)
        return cert_pub != key_pub

    def string_is_private_key(req_priv_key) -> bool:
        """Validate that a submitted string is in the format of a private key."""
        return bool(match("-----BEGIN RSA PRIVATE KEY-----", req_priv_key)) and bool(
            search("-----END RSA PRIVATE KEY-----", req_priv_key)
        )
