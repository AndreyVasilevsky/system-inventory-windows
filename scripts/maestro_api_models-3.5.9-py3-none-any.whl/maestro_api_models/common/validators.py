# INTEL CONFIDENTIAL
# Copyright 2022-2025 Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials,
# and your use of them is governed by the express license under which they
# were provided to you ("License"). Unless the License provides otherwise,
# you may not use, modify, copy, publish, distribute, disclose or transmit
# this software or the related documents without Intel's prior written
# permission.
#
# This software and the related documents are provided as is,
# with no express or implied warranties, other than those that
# are expressly stated in the License.

# Standard library imports
import datetime
from ipaddress import ip_address, IPv4Address, IPv6Address
import re
from typing import List, Union
from uuid import UUID

# Third party library imports
from dateutil import parser as dateutil_parser


def begin_str_with_number(char_str: str) -> bool:
    if re.match(r"^[0-9][0-9]*\.?[0-9]*?", char_str.lower()):
        return True
    else:
        raise ValueError(
            'must begin with an integer or decimal number (example: "8GT/s" or "2.5GT/s")'
        )


def valid_vlan(vlan: int) -> bool:
    if 0 <= vlan < 4096:
        return True
    raise ValueError("must be an integer between 0 and 4095")


def begin_str_with_alpha(char_str: str) -> bool:
    if re.match(r"^[a-zA-Z]+", char_str):
        return True
    else:
        raise ValueError("must begin with an alphabetic character")


def positive_number(num: float) -> bool:
    if num < 0:
        raise ValueError("must be a positive integer")
    return True


def positive_number_list(num_list: list[float]) -> bool:
    for num in num_list:
        try:
            positive_number(num)
        except ValueError as ve:
            raise ValueError(f"{ve} for each number in list")
    return True


def valid_char_count(
    char_str: str, max_len: int | None = None, min_len: int | None = None
) -> bool:

    if min_len is not None:
        if len(char_str) < min_len:
            raise ValueError(f"must be at least {min_len} characters long")

    if max_len is not None:
        if len(char_str) > max_len:
            raise ValueError(f"must not exceed length of {max_len} characters")

    return True


def valid_datetime_utc(
    datetime_val: Union[str, datetime.datetime], assume_utc_str: bool = False
) -> bool:
    try:
        if isinstance(datetime_val, str):
            datetime_val = dateutil_parser.parse(datetime_val)

        if datetime_val.utcoffset() is None:
            if not assume_utc_str:
                raise ValueError
        elif datetime_val.utcoffset().total_seconds() != 0:
            raise ValueError
    except ValueError:
        raise ValueError(
            'must be a valid 8601-format datetime string in UTC (example: "2023-02-16T10:15:00-00:00")'
        )
    return True


def valid_db_id_big_signed(db_id: int) -> bool:
    """
    Check if the given database ID is a valid signed BIGINT(20) value.

    Args:
        db_id (int): The database ID to validate.

    Returns:
        bool: True if the database ID is valid, False otherwise.

    Raises:
        ValueError: If the database ID is not an integer between 0 and 9223372036854775807.
    """
    if 0 < db_id < 9223372036854775807:
        return True
    raise ValueError("must be an integer between 0 and 9223372036854775807")


def valid_db_id_signed(db_id: int) -> bool:
    # INT(11) in Inventory DB
    if 0 < db_id < 2147483647:
        return True
    raise ValueError("must be an integer between 0 and 2147483647")


def valid_db_id_signed_list(num_list: list[int]) -> bool:
    for num in num_list:
        try:
            valid_db_id_signed(num)
        except ValueError as ve:
            raise ValueError(f"{ve} for each number in list")
    return True


def valid_db_id_unsigned(db_id: int) -> bool:
    # UNSIGNED INT(11) in Inventory DB
    if 0 < db_id < 4294967295:
        return True
    raise ValueError("must be an integer between 1 and 4294967295")


def valid_email(email: str) -> bool:
    """Check to make sure the email is valid.

    This check makes sure the first part isn't empty, there needs to be at least
    one @ sign, something after the @ sign, a period in the part after the @ sign,
    and something after the period.
    """
    if not re.match(r".+@.+\..+", email):
        raise ValueError("must be a valid email address.")
    return True


def valid_emails(emails: list[str]) -> bool:
    """Check each email in the list."""
    for email in emails:
        valid_email(email)
    return True


def valid_ip_address(ip: str) -> bool:
    # VARCHAR(39) in Inventory DB to support IPv4 and IPv6
    try:
        invalid = False if type(ip_address(ip)) in [IPv4Address, IPv6Address] else True
    except ValueError:
        invalid = True
    if invalid:
        raise ValueError("must be a valid IPv4 or IPv6 address")
    return True


def valid_kvm_field_characters(field: str) -> bool:
    if field is not None:
        if re.search(r"[!@$%^*|\\]", field):
            raise ValueError(
                "must not contain the following characters: ! @ $ % ^ * | \\"
            )
        return True


def valid_mac_address(mac: str) -> bool:
    # VARCHAR(17) in Inventory DB
    if re.match(r"[\da-f]{2}(:)[\da-f]{2}(\1[\da-f]{2}){4}$", mac.lower()):
        return True
    else:
        raise ValueError('must be a valid MAC address (example: "aa:bb:cc:dd:ee:ff")')


def valid_pool_name(pool_name: str):
    # VARCHAR(80) in Inventory DB. Allowable chars: [a-z], [A-Z], '_', '&', '-'
    if pool_name is not None:
        if re.match(r"^[\w&_-]{1,80}$", pool_name):
            return True
        else:
            raise ValueError(
                "must have a length of 1-80 only alphanumeric and/or the special characters '&', '_', '-'"
            )


def valid_uuid(uuid: str) -> bool:
    # CHAR(36) in Inventory DB
    try:
        if len(uuid) != 36:
            raise ValueError
        UUID(uuid, version=4)
    except ValueError:
        raise ValueError(
            'must be a valid 36-character UUID without braces (example: "12345678-abcd-fedc-abfe-123456789012")'
        )
    return True


def valid_alphanumeric(char_str: str, additional_char_symbols: List[str] = []) -> bool:
    """
    Check if a string contains only alphanumeric characters and additional character symbols.

    Args:
        char_str (str): The string to be validated.
        additional_char_symbols (List[str], optional): A list of additional symbols that are allowed. Defaults to [].

    Raises:
        ValueError: If `additional_char_symbols` contains a string with more than one character.
        ValueError: If `char_str` contains characters other than alphanumeric characters and  character symbols.
    """
    for char in additional_char_symbols:
        if len(char) > 1:
            raise ValueError(
                "additional_char_symbols must be a list of single characters"
            )
    if not re.match(rf"^[a-zA-Z0-9{''.join(additional_char_symbols)}]*$", char_str):
        raise ValueError("must contain only alphanumeric characters")
    return True
